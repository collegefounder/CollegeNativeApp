package com.app.college.UserInterface;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import com.app.college.R;
import com.app.college.UserInterface.authenticate.login.LoginActivity;
import com.app.college.UserInterface.main.employee.EmployeeHomeActivity;
import com.app.college.UserInterface.main.students.HomeActivity;
import com.app.college.ui.authenticate.base.BaseAuthenticateActivity;
import com.app.college.ui.authenticate.contract.SplashContract;
import com.app.college.ui.authenticate.presentorImpl.SplashPresentorImpl;
import com.app.college.utils.Constants;
import com.app.college.utils.helpers.SharedPreferenceHelper;


public class SplashActivity extends Activity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if(new SharedPreferenceHelper(SplashActivity.this).getPref(Constants.LOGED_IN,false)) {

                    if(new SharedPreferenceHelper(SplashActivity.this).getPref(Constants.LOGED_STUDENT,true))
                    {
                    Intent home = new Intent(SplashActivity.this, HomeActivity.class);
                    startActivity(home);
                    finish();
                }
                else{
                        Intent intent = new Intent(SplashActivity.this, EmployeeHomeActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);
                    }
                }
                else{
                    Intent home = new Intent(SplashActivity.this, LoginActivity.class);
                    startActivity(home);
                    finish();
                }
            }
        }, Constants.SPLASH_TIME);

    }

}
