package com.app.college.UserInterface.authenticate;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.app.college.R;
import com.app.college.data.forgotPassword.ForgotPassword;
import com.app.college.ui.authenticate.base.BaseAuthenticateActivity;
import com.app.college.ui.authenticate.interactor.ForgotInteractor;
import com.app.college.ui.authenticate.intractorImpl.ForgotInteractorImpl;
import com.app.college.utils.CommonMethods;
import com.app.college.utils.Constants;
import com.app.college.utils.ToastUtils;
import com.app.college.utils.YesNoDialogListener;

import butterknife.BindView;
import butterknife.OnClick;

public class ResetPasswordActivity extends BaseAuthenticateActivity implements YesNoDialogListener,ForgotInteractor.OnCompleteListener {

    @BindView(R.id.tv_header)
    public TextView tvHeader;
    @BindView(R.id.iv_back)
    public ImageView ivBack;
    private ForgotInteractor forgotInteractor;
    @BindView(R.id.et_email)
    public TextView etEmail;


    public static void start(Context context) {
        Intent intent = new Intent(context, ResetPasswordActivity.class);
        context.startActivity(intent);
    }

    @Override
    protected int getContentId() {
        return R.layout.activity_reset_password;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        initViews();
    }

    private void initViews() {
        ivBack.setVisibility(View.VISIBLE);
        tvHeader.setText(getString(R.string.reset_password));
        forgotInteractor = new ForgotInteractorImpl();
    }

    @OnClick(R.id.btn_ok)
    public void onClickOk() {
        if (etEmail.getText().toString().isEmpty())
        {
            ToastUtils.shortToast(getString(R.string.enter_emailAddress));
        }
        else {
            CommonMethods.yesNoDialog(Constants.FORGOT_PASSWORD, getString(R.string.forgot_password),
                    getString(R.string.do_want_send_link_for_reset_email), this, this);
        }
    }

    @Override
    public void yesClicked(String type) {
        CommonMethods.showProgress(this);
        forgotInteractor.forgot(etEmail.getText().toString(),this);
    }

    @Override
    public void noClicked(String type) {

    }

    @OnClick(R.id.iv_back)
    public void onBackClick() {
        onBackPressed();
    }

    @Override
    public void onSuccess(ForgotPassword response) {
        CommonMethods.hideProgress();
        if (response.getReturn() == 1){
            ToastUtils.shortToast(response.getMessage());
            finish();
        }
        else{
            ToastUtils.shortToast(response.getMessage());
        }
    }

    @Override
    public void onFailure(Throwable throwable) {
        CommonMethods.hideProgress();
    }
}
