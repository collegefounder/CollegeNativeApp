package com.app.college.UserInterface.authenticate.chooseInstitute;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.app.college.R;
import com.app.college.UserInterface.authenticate.login.LoginActivity;
import com.app.college.UserInterface.authenticate.signUp.signUpEmployee.SignUpEmployeeBusinessActivity;
import com.app.college.UserInterface.main.students.HomeActivity;
import com.app.college.data.CommonResponse;
import com.app.college.data.Injector;
import com.app.college.data.InterfaceApi;
import com.app.college.data.TokenInjector;
import com.app.college.data.getInstitute.Datum;
import com.app.college.data.getInstitute.GetInstitute;
import com.app.college.ui.authenticate.interactor.GetInstituteInteractor;
import com.app.college.ui.authenticate.intractorImpl.GetInstituteInteractorImpl;
import com.app.college.utils.App;
import com.app.college.utils.CommonMethods;
import com.app.college.utils.Constants;
import com.app.college.utils.ToastUtils;
import com.app.college.utils.helpers.SharedPreferenceHelper;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by 123 on 06-06-2018.
 */

public class ChooseInstituteActivity extends AppCompatActivity implements GetInstituteInteractor.OnCompleteListener,
        ChooseInstituteAdapter.chooseInst {

    @BindView(R.id.rv_institutes)
    public RecyclerView rvInstitute;
    @BindView(R.id.iv_search)
    public ImageView ivSearch;
    @BindView(R.id.iv_back)
    public ImageView ivBack;
    @BindView(R.id.tv_header)
    public TextView tvHeader;
    private GetInstituteInteractor getInstituteInteractor;
    private List<Datum> institutenames = new ArrayList<>();
    InterfaceApi api;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_institute);
        ButterKnife.bind(this);
        ivBack.setVisibility(View.VISIBLE);
        tvHeader.setText(getString(R.string.choose_institute));
        getInstituteInteractor = new GetInstituteInteractorImpl();
        CommonMethods.showProgress(this);
        getInstituteInteractor.getInstitute(this);

        api= TokenInjector.provideApi(ChooseInstituteActivity.this);
    }

    @OnClick(R.id.iv_back)
    public void onBackClick(){
        onBackPressed();
    }

    @OnClick(R.id.iv_search)
    public void onSearch() {
    }

    @Override
    public void onSuccess(GetInstitute response) {
        CommonMethods.hideProgress();
        if (response.getReturn() == 1){
            institutenames.addAll(response.getData());
            rvInstitute.setLayoutManager(new LinearLayoutManager(this));
            ChooseInstituteAdapter chooseInstituteAdapter = new ChooseInstituteAdapter(this, institutenames,this);
            rvInstitute.setAdapter(chooseInstituteAdapter);
        }
        else{
            ToastUtils.shortToast(response.getMessage());
        }
    }

    @Override
    public void onFailure(Throwable throwable) {
        CommonMethods.hideProgress();
    }

    @Override
    public void onSelectInstitude(CommonResponse response) {

    }

    @Override
    public void callInstitudeId(int id) {
        //getInstituteInteractor.selectInstidte(id,this);
        CommonMethods.showProgress(this);
        if(!App.hasNetwork()){
            ToastUtils.shortToast("No Internet Connection");
            return;
        }
        api.selectIntitude(id).enqueue(new Callback<CommonResponse>() {
            @Override
            public void onResponse(Call<CommonResponse> call, Response<CommonResponse> response) {

                CommonMethods.hideProgress();
                if(response.isSuccessful()){
                    CommonResponse getResponse=response.body();
                    if (getResponse.getReturn() == 1){
                        ToastUtils.shortToast(getResponse.getMessage());
                        new SharedPreferenceHelper(ChooseInstituteActivity.this).savePref(Constants.LOGED_IN, true);
                        new SharedPreferenceHelper(ChooseInstituteActivity.this).savePref(Constants.LOGED_STUDENT, true);
                        Intent intent=new Intent(ChooseInstituteActivity.this, HomeActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);
                    }
                    else{
                        ToastUtils.shortToast(getResponse.getMessage());
                    }
                }
                else{
                    try{
                        String errorBody=response.errorBody().string();
                        JSONObject object=new JSONObject(errorBody);
                        String errorMessage=object.getString("message");
                        ToastUtils.shortToast(errorMessage);

                    }
                    catch (Exception e){
                        e.printStackTrace();
                        //onCompleteListener.onFailure(new Throwable("Server Error"));
                    }
                }
            }

            @Override
            public void onFailure(Call<CommonResponse> call, Throwable t) {
                CommonMethods.hideProgress();
            }
        });
    }
}