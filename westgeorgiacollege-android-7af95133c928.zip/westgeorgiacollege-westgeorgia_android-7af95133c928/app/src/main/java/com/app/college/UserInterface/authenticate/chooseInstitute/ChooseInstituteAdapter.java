package com.app.college.UserInterface.authenticate.chooseInstitute;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.app.college.R;
import com.app.college.UserInterface.main.students.HomeActivity;
import com.app.college.data.getInstitute.Datum;
import com.app.college.utils.Constants;
import com.app.college.utils.helpers.SharedPreferenceHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by 123 on 06-06-2018.
 */

public class ChooseInstituteAdapter extends RecyclerView.Adapter<ChooseInstituteAdapter.MyViewHolder> {
    Context context;
    private List<Datum> institutenames = new ArrayList<>();

    chooseInst mListerner;
    public ChooseInstituteAdapter(Context context, List<Datum> insitutenames,chooseInst mListerner) {
        this.context = context;
        this.institutenames = insitutenames;
        this.mListerner=mListerner;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_choose_institute, null);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, final int position) {
        holder.tvInsitituteNames.setText(institutenames.get(position).getName());

        holder.rlInstituteNames.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                new SharedPreferenceHelper(context).savePref(Constants.CLICKED_INST,"yes");
                mListerner.callInstitudeId(institutenames.get(position).getId());

            }
        });
    }

    @Override
    public int getItemCount() {
        return institutenames.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView tvInsitituteNames;
        RelativeLayout rlInstituteNames;

        public MyViewHolder(View itemView) {
            super(itemView);

            tvInsitituteNames = itemView.findViewById(R.id.tv_institute);
            rlInstituteNames = itemView.findViewById(R.id.rl_institute);
        }
    }

    interface chooseInst{

        public void callInstitudeId(int id);

    }
}
