package com.app.college.UserInterface.authenticate.chooseNearbyCollege;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.app.college.R;
import com.app.college.UserInterface.authenticate.chooseInstitute.ChooseInstituteActivity;
import com.app.college.data.CommonResponse;
import com.app.college.data.getInstitute.Datum;
import com.app.college.data.getInstitute.GetInstitute;
import com.app.college.data.model.ChooseCollege;
import com.app.college.ui.authenticate.interactor.GetInstituteInteractor;
import com.app.college.ui.authenticate.intractorImpl.GetInstituteInteractorImpl;
import com.app.college.utils.CommonMethods;
import com.app.college.utils.ToastUtils;
import com.app.college.utils.listener.AddListener;
import com.app.college.utils.listener.RemoveListener;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by 123 on 06-06-2018.
 */

public class ChooseNearbyCollegeActivity extends AppCompatActivity implements GetInstituteInteractor.OnCompleteListener,AddListener, RemoveListener {
    //
    @BindView(R.id.rv_colleges)
    public RecyclerView rvColleges;
    @BindView(R.id.iv_back)
    public ImageView ivBack;
    @BindView(R.id.tv_header)
    public TextView tvHeader;
    @BindView(R.id.btn_done)
    public Button btnDone;
    private GetInstituteInteractor instituteInteractor;
    private List<String> collegenames = new ArrayList<>();
    ArrayList<Datum> chooseCollegeList = new ArrayList<>();
    ArrayList<Datum> collegeList = new ArrayList<>();
    int position;
    ChooseNearbyCollegeAdapter chooseNearbyCollegeAdapter;
    @BindView(R.id.et_search)
    public EditText etSearch;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_nearby_college);
        ButterKnife.bind(this);

        ivBack.setVisibility(View.VISIBLE);
        tvHeader.setText(getString(R.string.choose_nearby_colleges));
        instituteInteractor = new GetInstituteInteractorImpl();
        position = getIntent().getIntExtra("position",0);
        initAdapter();
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                filter(etSearch.getText().toString());
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                // TODO Auto-generated method stub
            }

            @Override
            public void afterTextChanged(Editable s) {

                // TODO Auto-generated method stub
            }
        });
    }

    @OnClick(R.id.btn_done)
    public void onDone() {
        Intent intent = new Intent();
        intent.putExtra("list", chooseCollegeList);
        intent.putExtra("position",position);
        setResult(RESULT_OK, intent);
        finish();
//        Intent intent = new Intent(ChooseNearbyCollegeActivity.this, ChooseInstituteActivity.class);
//        startActivity(intent);
    }

    @OnClick(R.id.iv_back)
    public void onBackClick() {
        onBackPressed();
    }

    private void initAdapter() {
        CommonMethods.showProgress(this);
        if ((ArrayList<Datum>)getIntent().getSerializableExtra("list") != null) {
            chooseCollegeList = (ArrayList<Datum>) getIntent().getSerializableExtra("list");
            RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);
            rvColleges.setLayoutManager(layoutManager);
            chooseNearbyCollegeAdapter = new ChooseNearbyCollegeAdapter(chooseCollegeList,position, this,this,this);
            rvColleges.setAdapter(chooseNearbyCollegeAdapter);
        }
            instituteInteractor.getInstitute(this);
//        ChooseCollege chooseCollege = new ChooseCollege();
//        chooseCollege.setChecked(false);
//        chooseCollege.setName("West Georgia");
//        chooseCollegeList.add(chooseCollege);
//
//        ChooseCollege chooseCollege1 = new ChooseCollege();
//        chooseCollege1.setChecked(false);
//        chooseCollege1.setName("College 2");
//        chooseCollegeList.add(chooseCollege1);
//
//        ChooseCollege chooseCollege2 = new ChooseCollege();
//        chooseCollege2.setChecked(false);
//        chooseCollege2.setName("College 3");
//        chooseCollegeList.add(chooseCollege2);
//
//        ChooseCollege chooseCollege3 = new ChooseCollege();
//        chooseCollege3.setChecked(false);
//        chooseCollege3.setName("College 4");
//        chooseCollegeList.add(chooseCollege3);
//
//        ChooseCollege chooseCollege4 = new ChooseCollege();
//        chooseCollege4.setChecked(false);
//        chooseCollege4.setName("College 5");
//        chooseCollegeList.add(chooseCollege4);

    }

    @Override
    public void onSuccess(GetInstitute response) {
        CommonMethods.hideProgress();
        if (response.getReturn() == 1) {
            collegeList.clear();
            for (Datum model : response.getData())
            {
                collegeList.add(model);
            }
            for(Datum datum : collegeList){
                for(Datum selectedDatum : chooseCollegeList){
                    if(datum.getId().equals(selectedDatum.getId())){
                        datum.setSelected(true);
                    }
                }
            }

            rvColleges.setLayoutManager(new LinearLayoutManager(this));
            chooseNearbyCollegeAdapter = new ChooseNearbyCollegeAdapter(collegeList,position, this,this,this);
            rvColleges.setAdapter(chooseNearbyCollegeAdapter);
        }
        else{
            ToastUtils.shortToast(response.getMessage());
        }
    }

    @Override
    public void onFailure(Throwable throwable) {
        CommonMethods.hideProgress();
    }

    @Override
    public void onSelectInstitude(CommonResponse response) {

    }

    @Override
    public void onClick(View view, int position) {
        chooseCollegeList.add(collegeList.get(position));
        this.position = position;
        chooseNearbyCollegeAdapter.update();
    }

    @Override
    public void onRemove(View view, int position) {
        chooseCollegeList.remove(collegeList.get(position));
    }


    private void filter(String text) {
        //new array list that will hold the filtered data
        ArrayList<Datum> filterdNames = new ArrayList<>();

        //looping through existing elements
        if (collegeList.size() != 0) {
            for (Datum s : collegeList) {
                //if the existing elements contains the search input
                if (s.getName().toLowerCase().contains(text.toLowerCase())) {
                    //adding the element to filtered list
                    filterdNames.add(s);
                }
            }

            //calling a method of the adapter class and passing the filtered list
            chooseNearbyCollegeAdapter.filterList(filterdNames);
        }
    }

}
