package com.app.college.UserInterface.authenticate.chooseNearbyCollege;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.app.college.R;
import com.app.college.data.getInstitute.Datum;
import com.app.college.data.model.ChooseCollege;
import com.app.college.utils.listener.AddListener;
import com.app.college.utils.listener.RemoveListener;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by 123 on 06-06-2018.
 */

public class ChooseNearbyCollegeAdapter extends RecyclerView.Adapter<ChooseNearbyCollegeAdapter.ViewHolder> {

    Context context;
    private List<Datum> collegeList = new ArrayList<>();
//    List<ChooseCollege> chooseCollege = new ArrayList<>();
    private int checked = 0;
    private AddListener addListener;
    private RemoveListener removeListener;
    int pos;

    public ChooseNearbyCollegeAdapter(List<Datum> collegeList,int pos, Context context, AddListener addListener,RemoveListener removeListener) {
        this.collegeList = collegeList;
        this.context = context;
        this.addListener = addListener;
        this.removeListener = removeListener;
        this.pos = pos;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_choose_nearby_college, null);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {

        holder.tvCollegeNames.setText(collegeList.get(position).getName());

        if (collegeList.get(position).isSelected()){
            holder.ivSelectCollege.setImageResource(R.mipmap.ic_check_box);
        }
        else{
            holder.ivSelectCollege.setImageResource(R.mipmap.ic_uncheckbox);
        }

        holder.ivSelectCollege.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                    holder.ivSelectCollege.setImageResource(R.mipmap.ic_check_box);
//                    pos = position;
                if(!collegeList.get(position).isSelected()){
                    holder.ivSelectCollege.setImageResource(R.mipmap.ic_check_box);
                    collegeList.get(position).setSelected(true);
                    addListener.onClick(view,position);
                }
                else{
                    holder.ivSelectCollege.setImageResource(R.mipmap.ic_uncheckbox);
                    collegeList.get(position).setSelected(false);
                    removeListener.onRemove(view,position);
                }
                notifyDataSetChanged();
            }
        });

    }

    @Override
    public int getItemCount() {
        return collegeList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvCollegeNames;
        ImageView ivSelectCollege;
        RelativeLayout rlCollegesNames;

        public ViewHolder(View itemView) {
            super(itemView);

            tvCollegeNames = itemView.findViewById(R.id.tv_college_names);
            ivSelectCollege = itemView.findViewById(R.id.iv_select_college);
            rlCollegesNames = itemView.findViewById(R.id.rl_colleges_names);
        }
    }

    public void update(){
        notifyDataSetChanged();
    }

    public void filterList(List<Datum> friendListModelList) {
        this.collegeList = friendListModelList;
        notifyDataSetChanged();
    }

}
