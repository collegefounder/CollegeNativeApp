package com.app.college.UserInterface.authenticate.login;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.util.Base64;
import android.util.Log;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.app.college.R;
import com.app.college.UserInterface.authenticate.ResetPasswordActivity;
import com.app.college.UserInterface.authenticate.chooseInstitute.ChooseInstituteActivity;
import com.app.college.UserInterface.authenticate.signUp.SignUpSelectorActivity;
import com.app.college.UserInterface.authenticate.signUp.signUpStudent.SignUpStudentActivity;
import com.app.college.UserInterface.main.employee.EmployeeHomeActivity;
import com.app.college.UserInterface.main.students.HomeActivity;
import com.app.college.data.checkSocialId.CheckSocialId;
import com.app.college.data.login.LoginBean;
import com.app.college.ui.authenticate.base.BaseAuthenticateActivity;
import com.app.college.ui.authenticate.interactor.CheckLoginInteractor;
import com.app.college.ui.authenticate.intractorImpl.CheckLoginInteractorImpl;
import com.app.college.ui.authenticate.presenter.LoginPresenter;
import com.app.college.ui.authenticate.presentorImpl.LoginPresenterImpl;
import com.app.college.ui.authenticate.view.LoginView;
import com.app.college.ui.base.BaseActivity;
import com.app.college.utils.CommonMethods;
import com.app.college.utils.Constants;
import com.app.college.utils.ToastUtils;
import com.app.college.utils.helpers.FacebookHelper;
import com.app.college.utils.helpers.GoogleHelper;
import com.app.college.utils.helpers.SharedPreferenceHelper;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.login.LoginManager;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.linkedin.platform.APIHelper;
import com.linkedin.platform.LISessionManager;
import com.linkedin.platform.errors.LIApiError;
import com.linkedin.platform.errors.LIAuthError;
import com.linkedin.platform.listeners.ApiListener;
import com.linkedin.platform.listeners.ApiResponse;
import com.linkedin.platform.listeners.AuthListener;
import com.linkedin.platform.utils.Scope;
import com.twitter.sdk.android.core.Callback;
import com.twitter.sdk.android.core.DefaultLogger;
import com.twitter.sdk.android.core.Result;
import com.twitter.sdk.android.core.Twitter;
import com.twitter.sdk.android.core.TwitterAuthConfig;
import com.twitter.sdk.android.core.TwitterAuthToken;
import com.twitter.sdk.android.core.TwitterConfig;
import com.twitter.sdk.android.core.TwitterCore;
import com.twitter.sdk.android.core.TwitterException;
import com.twitter.sdk.android.core.TwitterSession;
import com.twitter.sdk.android.core.identity.TwitterAuthClient;
import com.twitter.sdk.android.core.identity.TwitterLoginButton;
import com.twitter.sdk.android.core.models.User;

import org.json.JSONException;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import retrofit2.Call;

public class LoginActivity extends FragmentActivity implements GoogleHelper.GoogleHelperCallback,LoginView,FacebookHelper.FacebookHelperCallback, CheckLoginInteractor.OnCompleteListener{


    @BindView(R.id.tv_header)
    public TextView tvHeader;
    @BindView(R.id.iv_back)
    public ImageView ivBack;
    @BindView(R.id.et_email)
    public EditText etEmail;
    @BindView(R.id.et_password)
    public EditText etPassword;
    private GoogleHelper googleHelper;
    boolean isGoogleLogin;
    private String TAG = LoginActivity.class.getSimpleName();
    private LoginPresenter presenter;
    private String deviceToken;
    private FacebookHelper facebookHelper;
    private CheckLoginInteractor checkLoginInteractor;
    private String fbEmail;
    private String fbName;
    private String fbImage;
    private String fbId;
    private String fbAge;
    private String fbGender;
    private boolean isTwitterLogin;
    private boolean isFacebookLogin;
    private String twitterId;
    private TwitterAuthClient client;
    private String socialId;
    private int socialType;
    private String googleId;
    private String linkedInId;

    @BindView(R.id.twitter_login_btn)
    public TwitterLoginButton twitterLoginButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        ButterKnife.bind(this);
        setData();
        initViews();
    }

    private void initViews() {
        FacebookSdk.sdkInitialize(this);
        TwitterConfig config = new TwitterConfig.Builder(this)
                .logger(new DefaultLogger(Log.DEBUG))//enable logging when app is in debug mode
                .twitterAuthConfig(new TwitterAuthConfig(getResources().getString(R.string.api_key), getResources().getString(R.string.api_secret)))//pass the created app Consumer KEY and Secret also called API Key and Secret
                .debug(true)//enable debug mode
                .build();

        //finally initialize twitter with created configs
        Twitter.initialize(config);
        client = new TwitterAuthClient();
        googleHelper = new GoogleHelper(this, this);
        facebookHelper = new FacebookHelper(this, this);
        presenter = new LoginPresenterImpl(this,this);
        deviceToken = "123456";
        checkLoginInteractor = new CheckLoginInteractorImpl();
        LoginManager.getInstance().logOut();
        printKeyHash(this);
    }

    private void setData() {
        tvHeader.setText(getString(R.string.login));
    }

    @OnClick(R.id.tv_forgot_password)
    public void onClickForgotpassword() {
        ResetPasswordActivity.start(this);
    }

    @OnClick(R.id.btn_login)
    public void onClickLogin() {
        presenter.validateCredentials(etEmail,etPassword);
    }

    @OnClick(R.id.tv_new_user)
    public void onClickNewUser() {
        SignUpSelectorActivity.start(this);
    }

    @OnClick(R.id.btn_facebook)
    public void onClickFacebook() {
        facebookHelper.logout();
        facebookHelper.login(this);
        isFacebookLogin = true;
    }

    @OnClick(R.id.btn_google)
    public void onClickGoogle() {
//        ToastUtils.shortToast(getString(R.string.under_development));

        googleHelper.signOut();
        googleHelper.signIn();
        isGoogleLogin = true;

    }

    public static String printKeyHash(Activity context) {
        PackageInfo packageInfo;
        String key = null;
        try {
            //getting application package name, as defined in manifest
            String packageName = context.getApplicationContext().getPackageName();

            //Retriving package info
            packageInfo = context.getPackageManager().getPackageInfo(packageName,
                    PackageManager.GET_SIGNATURES);

            Log.e("Package Name=", context.getApplicationContext().getPackageName());

            for (Signature signature : packageInfo.signatures) {
                MessageDigest md = MessageDigest.getInstance("SHA");
                md.update(signature.toByteArray());
                key = new String(Base64.encode(md.digest(), 0));

                // String key = new String(Base64.encodeBytes(md.digest()));
                Log.e("Key Hash=", key);
            }
        } catch (PackageManager.NameNotFoundException e1) {
            Log.e("Name not found", e1.toString());
        }
        catch (NoSuchAlgorithmException e) {
            Log.e("No such an algorithm", e.toString());
        } catch (Exception e) {
            Log.e("Exception", e.toString());
        }

        return key;
    }

    @OnClick(R.id.btn_twitter)
    public void onClickTwitter() {
        isTwitterLogin = true;
        twitterLoginButton.setCallback(new Callback<TwitterSession>() {
            @Override
            public void success(Result<TwitterSession> result) {

                TwitterSession session = TwitterCore.getInstance().getSessionManager().getActiveSession();
                TwitterAuthToken authToken = session.getAuthToken();
                String token = authToken.token;
                String secret = authToken.secret;

                Call<User> user = TwitterCore.getInstance().getApiClient().getAccountService().verifyCredentials(true, false, true);

                user.enqueue(new Callback<User>() {
                    @Override
                    public void success(Result<User> result) {
                        socialId = String.valueOf(result.data.getId());
                        twitterId = String.valueOf(result.data.getId());
                        CommonMethods.showProgress(LoginActivity.this);
                        checkLoginInteractor.checkLogin(String.valueOf(result.data.getId()),deviceToken,"android", LoginActivity.this);

                    }

                    @Override
                    public void failure(TwitterException exception) {
                        ToastUtils.longToast(getString(R.string.twitter_authentication_failed));
                        isTwitterLogin = false;
                    }
                });
            }

            @Override
            public void failure(TwitterException exception) {
                // Do something on failure
                ToastUtils.longToast(getString(R.string.twitter_authentication_failed));
                isTwitterLogin = false;
            }
        });

        twitterLoginButton.performClick();
    }

    @OnClick(R.id.btn_linked_in)
    public void onClickLinkedIn() {
        LISessionManager.getInstance(this).clearSession();
        LISessionManager.getInstance(getApplicationContext()).init(this, buildScope()//pass the build scope here
                , new AuthListener() {
                    @Override
                    public void onAuthSuccess() {
                        // Authentication was successful. You can now do
                        // other calls with the SDK.
                        fetchBasicProfileData();
                //        Toast.makeText(LoginActivity.this, "Successfully authenticated with LinkedIn.", Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onAuthError(LIAuthError error) {
                        // Handle authentication errors
                        Log.e(TAG, "Auth Error :" + error.toString());
                        Toast.makeText(LoginActivity.this, "Failed to authenticate with LinkedIn. Please try again.", Toast.LENGTH_SHORT).show();
                    }
                }, true);
    }

    private static Scope buildScope() {
        return Scope.build(Scope.R_BASICPROFILE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(isGoogleLogin) {
            googleHelper.onResult(requestCode, resultCode, data);
        }
        else if (isTwitterLogin) {
                twitterLoginButton.onActivityResult(requestCode, resultCode, data);
        }
        else if(isFacebookLogin){
            facebookHelper.onResult(requestCode, resultCode, data);
        }
        else{
            LISessionManager.getInstance(getApplicationContext()).onActivityResult(this, requestCode, resultCode, data);
        }
    }


    @Override
    public void onSuccessFacebook(Bundle bundle) {
        if (bundle.getString("first_name") != null || bundle.get("last_name") != null) {
            fbName = bundle.getString("first_name") + " " + bundle.getString("last_name");
        }
        if (bundle.getString("email") != null) {
            fbEmail = bundle.getString("email");
        }
        if (bundle.getString("profile_pic") != null) {
            fbImage = bundle.getString("profile_pic");
        }
        if (bundle.getString("idFacebook") != null)
        {
            fbId = bundle.getString("idFacebook");
        }
        if (bundle.getString("birthday") != null){
            fbAge = bundle.getString("birthday");
        }
        if (bundle.getString("gender") != null){
            fbGender = bundle.getString("gender");
        }
        isFacebookLogin = false;
        socialId = fbId;
        CommonMethods.showProgress(this);
        new SharedPreferenceHelper(this).savePref(Constants.EMAIL,fbEmail);
        checkLoginInteractor.checkLogin(fbId,deviceToken,"android",this);
    }

    @Override
    public void onCancelFacebook() {
        isFacebookLogin = false;
    }

    @Override
    public void onErrorFacebook(FacebookException ex) {
        isFacebookLogin = false;
    }

    @Override
    public void onSuccessGoogle(GoogleSignInAccount account) {
        Map<String, String> fields = new HashMap<>();
        Log.e(TAG, "onSuccessGoogle: " + account.getDisplayName());
        fields.put("name", account.getDisplayName() == null ? "" : account.getDisplayName());
        fields.put("email", account.getEmail());
        fields.put("birthday", "");
        fields.put("deviceType", "android");
//        fields.put("deviceToken", SharedPreferenceHelper.getInstance().getFcmToken());
        fields.put("socialId", account.getId());

        Log.e(TAG, "onSuccessGoogle: BirthDay" + "" + account.getPhotoUrl());

        SharedPreferenceHelper.getInstance().saveGoogleProfilePic(String.valueOf(account.getPhotoUrl()));

//        presenter.googleLogin(fields);
        isGoogleLogin = false;
        googleId = account.getId();
        socialId = account.getId();
        new SharedPreferenceHelper(this).savePref(Constants.EMAIL,account.getEmail());
        CommonMethods.showProgress(this);
        checkLoginInteractor.checkLogin(account.getId(),deviceToken,"android",this);

    }

    @Override
    public void onErrorGoogle() {
        if (isFinishing()) {
            return;
        }
        CommonMethods.hideProgress();
        ToastUtils.longToast("Failed");
        isGoogleLogin = false;
    }

    @Override
    public void onSuccess(LoginBean response) {
        CommonMethods.hideProgress();
        if (response.getReturn() == 1) {
            new SharedPreferenceHelper(LoginActivity.this).savePref(Constants.LOGED_IN, true);

            new SharedPreferenceHelper(LoginActivity.this).savePref(Constants.LOGED_STUDENT, true);
            if (response.getData().getRole() == 1) {
               // String check = new SharedPreferenceHelper(LoginActivity.this).getPref(Constants.CLICKED_INST);
               // if((check!=null && check.equalsIgnoreCase("yes"))) {
                if(response.getData().getInstituteId()!=null && !response.getData().getInstituteId().equalsIgnoreCase(""))
                {
                    Intent intent = new Intent(LoginActivity.this, HomeActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    finish();
                }
                else{
                    Intent intent = new Intent(this, ChooseInstituteActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                    finish();
                }
                new SharedPreferenceHelper(this).savePref(Constants.AUTH_TOKEN,response.getData().getAccessToken());
            }
            else{
                new SharedPreferenceHelper(LoginActivity.this).savePref(Constants.LOGED_STUDENT, false);
                Intent intent = new Intent(LoginActivity.this, EmployeeHomeActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
                new SharedPreferenceHelper(this).savePref(Constants.AUTH_TOKEN,response.getData().getAccessToken());
            }
        }
        else{
            ToastUtils.shortToast(response.getMessage());
        }
    }

    @Override
    public void onFailure(String throwable) {
        CommonMethods.hideProgress();
    }

    @Override
    public void onValidationSuccess() {
        CommonMethods.showProgress(this);
        presenter.login(etEmail.getText().toString(),etPassword.getText().toString(),"android",deviceToken);
    }

    @Override
    public void onSuccess(CheckSocialId response) {
        CommonMethods.hideProgress();
        if (response.getReturn() == 1)
        {
            new SharedPreferenceHelper(LoginActivity.this).savePref(Constants.LOGED_IN, true);
            Intent home = new Intent(this,HomeActivity.class);
            home.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(home);
            finish();
            new SharedPreferenceHelper(this).savePref(Constants.AUTH_TOKEN,response.getData().getAccessToken());
        }
        else {
//            ToastUtils.shortToast(response.getMessage());
            if (fbId != null){
                socialType = 1;
            }
            else if(twitterId != null){
                socialType = 3;
            }
            else if(googleId != null){
                socialType = 2;
            }
            else if(linkedInId != null){
                socialType = 4;
            }

            if (response.getMessage().equalsIgnoreCase("social Id does not exist"))
            {
                Intent social = new Intent(this,SignUpSelectorActivity.class);
                social.putExtra("from","social");
                social.putExtra("id",socialId);
                social.putExtra("type",socialType);
                startActivity(social);
            }
        }
    }

    @Override
    public void onFailure(Throwable throwable) {
        CommonMethods.hideProgress();

    }

    private void fetchBasicProfileData() {

        //In URL pass whatever data from user you want for more values check below link
        //LINK : https://developer.linkedin.com/docs/fields/basic-profile
        String url = "https://api.linkedin.com/v1/people/~:(id,first-name,last-name,headline,public-profile-url,picture-url,email-address,picture-urls::(original))";

        APIHelper apiHelper = APIHelper.getInstance(getApplicationContext());
        apiHelper.getRequest(this, url, new ApiListener() {
            @Override
            public void onApiSuccess(ApiResponse apiResponse) {
                // Success!
                Log.d(TAG, "API Res : " + apiResponse.getResponseDataAsString() + "\n" + apiResponse.getResponseDataAsJson().toString());
             //   Toast.makeText(LoginActivity.this, "Successfully fetched LinkedIn profile data.", Toast.LENGTH_SHORT).show();
                try {
                    linkedInId = apiResponse.getResponseDataAsJson().getString("id");
                    socialId = apiResponse.getResponseDataAsJson().getString("id");
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                checkLoginInteractor.checkLogin(socialId,deviceToken,"android",LoginActivity.this);
            }

            @Override
            public void onApiError(LIApiError liApiError) {
                // Error making GET request!
                Log.e(TAG, "Fetch profile Error   :" + liApiError.getLocalizedMessage());
                Toast.makeText(LoginActivity.this, "Failed to fetch basic profile data. Please try again.", Toast.LENGTH_SHORT).show();
            }
        });
    }

}
