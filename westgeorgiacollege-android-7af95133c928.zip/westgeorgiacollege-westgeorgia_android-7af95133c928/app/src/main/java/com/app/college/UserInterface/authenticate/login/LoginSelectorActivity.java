package com.app.college.UserInterface.authenticate.login;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import com.app.college.R;
import com.app.college.UserInterface.authenticate.signUp.SignUpSelectorActivity;
import com.app.college.UserInterface.authenticate.signUp.signUpEmployee.SignUpEmployeeBusinessActivity;
import com.app.college.UserInterface.authenticate.signUp.signUpStudent.SignUpStudentActivity;
import com.app.college.ui.authenticate.base.BaseAuthenticateActivity;

import butterknife.OnClick;

/**
 * Created by 123 on 12-06-2018.
 */

public class LoginSelectorActivity extends BaseAuthenticateActivity {


    public static void start(Context context) {
        Intent intent = new Intent(context, SignUpSelectorActivity.class);
        context.startActivity(intent);
    }

    @Override
    protected int getContentId() {
        return R.layout.activity_login_selector;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @OnClick(R.id.btn_student)
    public void onClickStudent() {
        Intent student = new Intent(this,SignUpStudentActivity.class);
        startActivity(student);

    }

    @OnClick(R.id.btn_employee_business)
    public void onclickEmployeebusiness() {
        SignUpEmployeeBusinessActivity.start(this);
    }

}
