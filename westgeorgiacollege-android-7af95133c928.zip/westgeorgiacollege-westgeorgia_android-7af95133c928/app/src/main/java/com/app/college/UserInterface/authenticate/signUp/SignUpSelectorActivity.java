package com.app.college.UserInterface.authenticate.signUp;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.app.college.R;
import com.app.college.UserInterface.authenticate.signUp.signUpEmployee.SignUpEmployeeBusinessActivity;
import com.app.college.UserInterface.authenticate.signUp.signUpStudent.SignUpStudentActivity;
import com.app.college.data.socialLoginStudent.SocialLoginStudent;
import com.app.college.ui.authenticate.base.BaseAuthenticateActivity;
import com.app.college.ui.authenticate.interactor.SocialStudentInteractor;
import com.app.college.ui.authenticate.intractorImpl.SocialStudentInteractorImpl;
import com.app.college.utils.CommonMethods;
import com.app.college.utils.ToastUtils;
import com.app.college.utils.helpers.FacebookHelper;
import com.facebook.FacebookException;

import butterknife.BindView;
import butterknife.OnClick;

public class SignUpSelectorActivity extends BaseAuthenticateActivity {

    @BindView(R.id.iv_back)
    public ImageView ivBack;
    @BindView(R.id.tv_header)
    public TextView tvheader;
    String from;
    private String deviceToken;
    private String socialId;
    private int socialType;


    public static void start(Context context) {
        Intent intent = new Intent(context, SignUpSelectorActivity.class);
        intent.putExtra("from","normal");
        context.startActivity(intent);
    }

    @Override
    protected int getContentId() {
        return R.layout.activity_sign_up_selector;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        from = getIntent().getStringExtra("from");
        socialId = getIntent().getStringExtra("id");
        socialType = getIntent().getIntExtra("type",0);
        initViews();
    }

    private void initViews() {
        ivBack.setVisibility(View.GONE);
        tvheader.setText(getString(R.string.sign_up));
        deviceToken = "123456";
    }

    @OnClick(R.id.btn_student)
    public void onClickStudent() {
        Intent student = new Intent(this,SignUpStudentActivity.class);
        student.putExtra("from",from);
        student.putExtra("id",socialId);
        student.putExtra("type",socialType);
        startActivity(student);
    }

    @OnClick(R.id.btn_employee_business)
    public void onclickEmployeebusiness() {
        Intent business = new Intent(this,SignUpEmployeeBusinessActivity.class);
        business.putExtra("from",from);
        business.putExtra("id",socialId);
        business.putExtra("type",socialType);
        startActivity(business);
    }

    @OnClick(R.id.iv_back)
    public void onClickBack() {
        onBackPressed();
    }

}
