package com.app.college.UserInterface.authenticate.signUp.signUpEmployee;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import com.app.college.R;
import com.app.college.UserInterface.authenticate.chooseInstitute.ChooseInstituteActivity;
import com.app.college.UserInterface.authenticate.chooseNearbyCollege.ChooseNearbyCollegeActivity;
import com.app.college.UserInterface.authenticate.login.LoginActivity;
import com.app.college.data.businessSignup.BusinessSignup;
import com.app.college.data.getInstitute.Datum;
import com.app.college.data.socialLoginBusiness.BusinessSocialSignup;
import com.app.college.ui.authenticate.base.BaseAuthenticateActivity;
import com.app.college.UserInterface.main.employee.EmployeeHomeActivity;
import com.app.college.ui.authenticate.interactor.GetInstituteInteractor;
import com.app.college.ui.authenticate.interactor.SocialBusinessSignupInteractor;
import com.app.college.ui.authenticate.intractorImpl.BusinessSocialSignUpInteractorImpl;
import com.app.college.ui.authenticate.intractorImpl.GetInstituteInteractorImpl;
import com.app.college.ui.authenticate.presenter.BusinessSignUpPresenter;
import com.app.college.ui.authenticate.presentorImpl.BusinessSignUpPresenterImpl;
import com.app.college.ui.authenticate.view.BusinessSignUpView;
import com.app.college.utils.CommonMethods;
import com.app.college.utils.Constants;
import com.app.college.utils.ToastUtils;
import com.app.college.utils.helpers.SharedPreferenceHelper;
import org.json.JSONArray;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import butterknife.BindView;
import butterknife.OnClick;

public class SignUpEmployeeBusinessActivity extends BaseAuthenticateActivity implements BusinessSignUpView,BusinessSocialSignUpInteractorImpl.OnCompleteListener{

    @BindView(R.id.iv_back)
    public ImageView ivBack;
    @BindView(R.id.tv_header)
    public TextView tvHeader;
    @BindView(R.id.tv_select_user_type)
    public TextView tvSelectCollege;
    @BindView(R.id.rv_select_user_type)
    public RecyclerView rvSelectUserType;
    @BindView(R.id.et_business_name)
    public EditText etBusinessName;
    @BindView(R.id.et_business_address)
    public EditText etBusinessAddress;
    @BindView(R.id.et_gen_acc_man_name)
    public EditText etGenAccManName;
    @BindView(R.id.et_phone_number)
    public EditText etPhoneNumber;
    @BindView(R.id.et_email_address)
    public EditText etEmailAddress;
    @BindView(R.id.et_phone_number_for_student)
    public EditText etPhoneNumberStudent;
    @BindView(R.id.et_email_address_for_student)
    public EditText etEmailAddStudent;
    @BindView(R.id.et_password)
    public EditText etPwd;
    @BindView(R.id.et_confirm_password)
    public EditText etConfirmPwd;
    private GetInstituteInteractor getInstituteInteractor;
    private BusinessSignUpPresenter businessSignUpPresenter;
    private List<Datum> useroptions = new ArrayList<>();
    private ArrayList<Integer> nearbyColleges = new ArrayList<>();
    private String deviceToken;
    private int collegeId;
    int position = -1;
    private String socialId;
    private int socialType;
    String from;
    private SocialBusinessSignupInteractor socialBusinessInteractor;
    SharedPreferenceHelper mPref;
    String email;

    public static void start(Context context) {
        Intent intent = new Intent(context, SignUpEmployeeBusinessActivity.class);
        intent.putExtra("from","normal");
        context.startActivity(intent);
    }

    @Override
    protected int getContentId() {
        return R.layout.activity_sign_up_employee_business;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mPref =new SharedPreferenceHelper(SignUpEmployeeBusinessActivity.this);
        email = mPref.getPref(Constants.EMAIL,null);
        initViews();

    }

    @OnClick(R.id.rl_choose)
    public void selectCollege(){
        int pos;
        if (position != -1) {
            pos = position;
        }
        else{
            pos = -1;
        }
        Intent select = new Intent(this, ChooseNearbyCollegeActivity.class);
        select.putExtra("list", (Serializable) useroptions);
        select.putExtra("position",pos);
        startActivityForResult(select, 1);
    }


    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1) {
            if(resultCode == RESULT_OK) {
                useroptions = (ArrayList<Datum>) data.getSerializableExtra("list");
                position = data.getIntExtra("position",-1);
                RecyclerView.LayoutManager mlayoutManager = new LinearLayoutManager(this);
                rvSelectUserType.setLayoutManager(mlayoutManager);
                SignupEmployeeAdapter uadapter = new SignupEmployeeAdapter(this,useroptions);
                rvSelectUserType.setAdapter(uadapter);
            }
        }
    }

    private void initViews() {
        getInstituteInteractor = new GetInstituteInteractorImpl();
        businessSignUpPresenter = new BusinessSignUpPresenterImpl(this,this);
        socialBusinessInteractor = new BusinessSocialSignUpInteractorImpl();
        ivBack.setVisibility(View.VISIBLE);
        tvHeader.setText(getString(R.string.sign_up));
        deviceToken = "123456";
        socialId = getIntent().getStringExtra("id");
        socialType = getIntent().getIntExtra("type",0);
        from = getIntent().getStringExtra("from");
        Log.e("from","from" +from +" socialid "+socialId +"socialType "+socialType);
        if(!from.equalsIgnoreCase("normal"))
        {
            etPwd.setVisibility(View.GONE);
            etConfirmPwd.setVisibility(View.GONE);
        }
        if(email!=null)
            etEmailAddress.setText(email);
    }

    @OnClick(R.id.iv_back)
    public void onClickBack() {
        onBackPressed();
    }

    @OnClick(R.id.btn_submit)
    public void onClickSubmit() {
        businessSignUpPresenter.validateCredentials(etBusinessName,etBusinessAddress,etGenAccManName,etPhoneNumber,etEmailAddress,etPhoneNumberStudent,etEmailAddStudent,etPwd,etConfirmPwd,from);
    }


    @Override
    public void onSuccess(BusinessSignup response) {
        CommonMethods.hideProgress();
        if (response.getReturn() == 1){
            new SharedPreferenceHelper(SignUpEmployeeBusinessActivity.this).savePref(Constants.LOGED_IN, true);
            new SharedPreferenceHelper(SignUpEmployeeBusinessActivity.this).savePref(Constants.LOGED_STUDENT, false);
            Intent intent = new Intent(this, EmployeeHomeActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
            new SharedPreferenceHelper(this).savePref(Constants.AUTH_TOKEN,response.getData().getAccessToken());
        }
        else{
            ToastUtils.shortToast(response.getMessage());
        }
    }

    @Override
    public void onFailure(String throwable) {
        CommonMethods.hideProgress();
    }

    @Override
    public void onValidationSuccess() {
        if (useroptions.size() == 0){
            ToastUtils.shortToast(getString(R.string.choose_one_college));
        }
        else {
            nearbyColleges.clear();
            for (int i = 0; i < useroptions.size(); i++) {
                collegeId = useroptions.get(i).getId();
                nearbyColleges.add(collegeId);
            }
            JSONArray collegesArray = new JSONArray(nearbyColleges);
            CommonMethods.showProgress(this);
            if (from.equalsIgnoreCase("social")){
                socialBusinessInteractor.businessSocial(String.valueOf(socialType),socialId,etBusinessName.getText().toString(), etBusinessAddress.getText().toString(), etGenAccManName.getText().toString(),
                        etPhoneNumber.getText().toString(), etEmailAddress.getText().toString(), etPhoneNumberStudent.getText().toString(), etEmailAddStudent.getText().toString(), etPwd.getText().toString(), collegesArray, "android", deviceToken,this);
            }
            else{
                businessSignUpPresenter.businessSignup(etBusinessName.getText().toString(), etBusinessAddress.getText().toString(), etGenAccManName.getText().toString(),
                        etPhoneNumber.getText().toString(), etEmailAddress.getText().toString(), etPhoneNumberStudent.getText().toString(), etEmailAddStudent.getText().toString(), etPwd.getText().toString(), collegesArray, "android", deviceToken);

            }
        }
    }

    @Override
    public void onSuccess(BusinessSocialSignup response) {
        CommonMethods.hideProgress();
        if (response.getReturn() == 1){
            Intent intent = new Intent(this, EmployeeHomeActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
            new SharedPreferenceHelper(this).savePref(Constants.AUTH_TOKEN,response.getData().getAccessToken());
        }
        else{
            ToastUtils.shortToast(response.getMessage());
        }
    }

    @Override
    public void onFailure(Throwable throwable) {
        CommonMethods.hideProgress();
    }
}
