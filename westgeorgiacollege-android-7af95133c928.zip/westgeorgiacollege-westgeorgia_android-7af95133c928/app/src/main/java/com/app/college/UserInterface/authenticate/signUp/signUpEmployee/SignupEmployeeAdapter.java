package com.app.college.UserInterface.authenticate.signUp.signUpEmployee;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.app.college.R;
import com.app.college.data.getInstitute.Datum;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by 123 on 06-06-2018.
 */

public class SignupEmployeeAdapter extends RecyclerView.Adapter<SignupEmployeeAdapter.MyViewHolder> {
    Context context;
    List<Datum> useroptions= new ArrayList<>();

    public SignupEmployeeAdapter(Context context,List<Datum> useroptions)
    {
        this.context=context;
        this.useroptions=useroptions;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_signup_employee,null);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, final int position) {
        holder.tvOptions.setText(useroptions.get(position).getName());

        holder.ivCross.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                useroptions.remove(position);
                notifyDataSetChanged();
            }
        });
    }

    @Override
    public int getItemCount() {
        return useroptions.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView tvOptions;
        ImageView ivCross;

        public MyViewHolder(View itemView) {
            super(itemView);
            tvOptions=itemView.findViewById(R.id.tv_options);
            ivCross=itemView.findViewById(R.id.iv_cross);
        }
    }
}