package com.app.college.UserInterface.authenticate.signUp.signUpStudent;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.app.college.R;
import com.app.college.UserInterface.SplashActivity;
import com.app.college.UserInterface.authenticate.chooseInstitute.ChooseInstituteActivity;
import com.app.college.UserInterface.main.students.HomeActivity;
import com.app.college.data.socialLoginStudent.SocialLoginStudent;
import com.app.college.data.studentSignUp.StudentSignup;
import com.app.college.ui.authenticate.base.BaseAuthenticateActivity;
import com.app.college.ui.authenticate.interactor.SocialStudentInteractor;
import com.app.college.ui.authenticate.intractorImpl.SocialStudentInteractorImpl;
import com.app.college.ui.authenticate.presenter.StudentSignUpPresenter;
import com.app.college.ui.authenticate.presentorImpl.StudentSignUpPresenterImpl;
import com.app.college.ui.authenticate.view.StudentSignUpView;
import com.app.college.utils.CommonMethods;
import com.app.college.utils.Constants;
import com.app.college.utils.ToastUtils;
import com.app.college.utils.helpers.SharedPreferenceHelper;


import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class SignUpStudentActivity extends Activity implements StudentSignUpView,SocialStudentInteractor.OnCompleteListener{

    @BindView(R.id.iv_back)
    public ImageView ivBack;
    @BindView(R.id.tv_header)
    public TextView tvHeader;
    @BindView(R.id.et_address)
    public EditText etAddress;
    @BindView(R.id.et_first_name)
    public EditText etFirstName;
    @BindView(R.id.et_last_name)
    public EditText etLastName;
    @BindView(R.id.et_email)
    public EditText etEmail;
    @BindView(R.id.et_password)
    public EditText etPassword;
    @BindView(R.id.et_confirm_password)
    public EditText etConfirmPassword;
    @BindView(R.id.et_mobile_number)
    public EditText etMobileNumber;
    private StudentSignUpPresenter studentSignUpPresenter;
    private String deviceToken;
    private String from;
    private String socialId;
    private int socialType;
    private SocialStudentInteractor socialStudentInteractor;
    SharedPreferenceHelper mPref;
    String email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up_student);
        ButterKnife.bind(this);
        mPref =new SharedPreferenceHelper(SignUpStudentActivity.this);
        email = mPref.getPref(Constants.EMAIL,null);
        initViews();

    }

    private void initViews() {
        ivBack.setVisibility(View.VISIBLE);
        tvHeader.setText(getString(R.string.sign_up));
        from = getIntent().getStringExtra("from");
        socialId = getIntent().getStringExtra("id");
        socialType = getIntent().getIntExtra("type",0);
        Log.e("from","from" +from +" socialid "+socialId +"socialType "+socialType);
        studentSignUpPresenter = new StudentSignUpPresenterImpl(this,this);
        socialStudentInteractor = new SocialStudentInteractorImpl();
        deviceToken = "123456";

        if(!from.equalsIgnoreCase("normal"))
        {
            etPassword.setVisibility(View.GONE);
            etConfirmPassword.setVisibility(View.GONE);
        }
        if(email!=null)
            etEmail.setText(email);
    }

    @OnClick(R.id.btn_submit)
    public void onClickSubmit() {
//        ToastUtils.shortToast(getString(R.string.under_development));

        studentSignUpPresenter.validateCredentials(etFirstName,etLastName,etAddress,etEmail,etMobileNumber,etPassword,etConfirmPassword,from);

    }

    @OnClick(R.id.iv_back)
    public void onClickBack() {
        onBackPressed();
    }

    @Override
    public void onSuccess(StudentSignup response) {
        CommonMethods.hideProgress();
        if (response.getReturn() == 1){

//            String check = new SharedPreferenceHelper(SignUpStudentActivity.this).getPref(Constants.CLICKED_INST);
//            if((check!=null && check.equalsIgnoreCase("yes"))) {
//                Intent login = new Intent(this, HomeActivity.class);
//                login.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_NEW_TASK);
//                startActivity(login);
//                finish();
//            }
//            else{
                Intent intent = new Intent(this, ChooseInstituteActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                finish();
                //  new SharedPreferenceHelper(this).savePref(Constants.AUTH_TOKEN,response.getData().getAccessToken());

           // }
            new SharedPreferenceHelper(this).savePref(Constants.AUTH_TOKEN, response.getData().getAccessToken());
//            Intent intent= new Intent(this, ChooseInstituteActivity.class);
//            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_NEW_TASK);
//            startActivity(intent);
//            finish();
//            new SharedPreferenceHelper(this).savePref(Constants.AUTH_TOKEN,response.getData().getAccessToken());
        }
        else{
            ToastUtils.shortToast(response.getMessage());
        }
    }

    @Override
    public void onFailure(String throwable) {
        CommonMethods.hideProgress();
    }

    @Override
    public void onValidationSuccess() {
        CommonMethods.showProgress(this);
        if (from.equalsIgnoreCase("social")) {
            socialStudentInteractor.socialStudent(socialId,etFirstName.getText().toString(), etLastName.getText().toString(), etAddress.getText().toString(), etEmail.getText().toString(), etMobileNumber.getText().toString(), etPassword.getText().toString(), "android", deviceToken,String.valueOf(socialType),this);
        } else {
            studentSignUpPresenter.studentSignup(etFirstName.getText().toString(), etLastName.getText().toString(), etAddress.getText().toString(), etEmail.getText().toString(), etMobileNumber.getText().toString(), etPassword.getText().toString(), "android", deviceToken);
        }
    }


    @Override
    public void onSuccess(SocialLoginStudent response) {
        CommonMethods.hideProgress();
        if (response.getReturn() == 1){
//
//            String check = new SharedPreferenceHelper(SignUpStudentActivity.this).getPref(Constants.CLICKED_INST);
//            if((check!=null && check.equalsIgnoreCase("yes"))) {
//           Intent login = new Intent(this, HomeActivity.class);
//            login.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_NEW_TASK);
//            startActivity(login);
//            finish();
//            }
//            else{
                Intent intent = new Intent(this, ChooseInstituteActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                finish();
                //  new SharedPreferenceHelper(this).savePref(Constants.AUTH_TOKEN,response.getData().getAccessToken());
              //  new SharedPreferenceHelper(this).savePref(Constants.AUTH_TOKEN, response.getData().getAccessToken());
          //  }
            new SharedPreferenceHelper(this).savePref(Constants.AUTH_TOKEN, response.getData().getAccessToken());
        }
        else{
            ToastUtils.shortToast(response.getMessage());
        }
    }

    @Override
    public void onFailure(Throwable throwable) {
        CommonMethods.hideProgress();

    }
}
