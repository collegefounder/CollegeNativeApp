package com.app.college.UserInterface.main.employee;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.app.college.R;
import com.app.college.UserInterface.main.settings.SettingsActivity;
import com.app.college.ui.authenticate.base.BaseAuthenticateActivity;
import com.app.college.UserInterface.main.employee.empEvents.EmpEventsActivity;
import com.app.college.UserInterface.main.employee.empJobListing.EmpJobActivity;
import com.app.college.UserInterface.main.employee.empUploadJob.EmpUploadJobActivity;


import butterknife.BindView;
import butterknife.OnClick;

public class EmployeeHomeActivity extends BaseAuthenticateActivity {

    @BindView(R.id.iv_back)
    public ImageView ivBack;
    @BindView(R.id.tv_header)
    public TextView tvHeader;
    @BindView(R.id.iv_settings)
    public ImageView ivSettings;

    @Override
    protected int getContentId() {
        return R.layout.employee_home_activity;
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initViews();
    }

    private void initViews() {
        ivBack.setVisibility(View.GONE);
        tvHeader.setText(getString(R.string.home));
        ivSettings.setVisibility(View.VISIBLE);
    }

    @OnClick(R.id.ll_uploads)
    public void uploads() {
        EmpUploadJobActivity.start(this);
    }

    @OnClick(R.id.ll_events)
    public void events() {
        EmpEventsActivity.start(this);
    }

    @OnClick(R.id.ll_jobs)
    public void jobs() {
        EmpJobActivity.start(this);
    }

    @OnClick(R.id.iv_settings)
    public void onSettingsClick(){
        Intent intent=new Intent(this, SettingsActivity.class);
        startActivity(intent);
    }
}
