package com.app.college.UserInterface.main.employee.empEvents;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.app.college.R;
import com.app.college.ui.authenticate.base.BaseAuthenticateActivity;
import com.app.college.UserInterface.main.employee.empEvents.addEvent.AddEventActivity;
import com.app.college.UserInterface.main.employee.empEvents.eventDetails.EventDetailsActivity;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;

public class EmpEventsActivity extends BaseAuthenticateActivity implements EventsAdapter.OnClckEvent {

    @BindView(R.id.iv_back)
    public ImageView ivBack;
    @BindView(R.id.tv_header)
    public TextView tvHeader;
    @BindView(R.id.iv_add)
    public ImageView ivAddEvent;

    @BindView(R.id.recycler_view)
    public RecyclerView recyclerView;

    EventsAdapter eventsAdapter;

    public static void start(Context context) {
        Intent intent = new Intent(context, EmpEventsActivity.class);
        context.startActivity(intent);
    }

    @Override
    protected int getContentId() {
        return R.layout.activity_emp_events;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        initViews();
        iniAdapter();
    }

    private void initViews() {
        ivBack.setVisibility(View.VISIBLE);
        ivAddEvent.setVisibility(View.VISIBLE);
        tvHeader.setText(getString(R.string.events));
    }

    private void iniAdapter() {
        List<String> stringList = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            stringList.add("" + i);
        }

        eventsAdapter = new EventsAdapter(stringList, this, this);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setAdapter(eventsAdapter);
    }

    @OnClick(R.id.iv_back)
    public void onClickBack() {
        onBackPressed();
    }

    @OnClick(R.id.iv_add)
    public void onClickAddEvent() {
        AddEventActivity.start(this);
    }

    @Override
    public void onClickEventListener(int position) {
        EventDetailsActivity.start(this);
    }
}
