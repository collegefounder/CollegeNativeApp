package com.app.college.UserInterface.main.employee.empEvents;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import com.app.college.R;

import java.util.List;

public class EventsAdapter extends RecyclerView.Adapter<EventsAdapter.ViewHolder> {

    Context context;
    List<String> stringList;
    OnClckEvent onClckEvent;

    public EventsAdapter(List<String> stringList, OnClckEvent onClckEvent, Context context) {
        this.context = context;
        this.stringList = stringList;
        this.onClckEvent = onClckEvent;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_events, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {

        holder.rlEvents.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onClckEvent.onClickEventListener(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return stringList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        RelativeLayout rlEvents;

        public ViewHolder(View itemView) {
            super(itemView);

            rlEvents = (RelativeLayout) itemView.findViewById(R.id.rl_events);
        }
    }

    public interface OnClckEvent {
        void onClickEventListener(int position);
    }
}
