package com.app.college.UserInterface.main.employee.empEvents.addEvent;

import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.TextView;

import com.app.college.R;
import com.app.college.UserInterface.main.students.digitalCampus.dining.DiningActivity;


import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by 123 on 09-06-2018.
 */

public class AddEventActivity extends AppCompatActivity {

    @BindView(R.id.et_enter_event_name)
    public TextView etEventName;

    @BindView(R.id.et_event_location)
    public TextView etEventLocation;

    @BindView(R.id.tv_event_time)
    public TextView tvEventTime;

    private int mYear, mMonth, mDay;
    @BindView(R.id.iv_back)
    public ImageView ivBack;
    @BindView(R.id.tv_header)
    public TextView tvHeader;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_event);
        ButterKnife.bind(this);

        ivBack.setVisibility(View.VISIBLE);
        tvHeader.setText(getString(R.string.add_event));

        final TextView etEventDate = findViewById(R.id.et_event_date);
        etEventDate.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // To show current date in the datepicker
                Calendar mcurrentDate = Calendar.getInstance();
                mYear = mcurrentDate.get(Calendar.YEAR);
                mMonth = mcurrentDate.get(Calendar.MONTH);
                mDay = mcurrentDate.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog mDatePicker = new DatePickerDialog(AddEventActivity.this, new DatePickerDialog.OnDateSetListener() {
                    public void onDateSet(DatePicker datepicker, int selectedyear, int selectedmonth, int selectedday) {
                        Calendar myCalendar = Calendar.getInstance();
                        myCalendar.set(Calendar.YEAR, selectedyear);
                        myCalendar.set(Calendar.MONTH, selectedmonth);
                        myCalendar.set(Calendar.DAY_OF_MONTH, selectedday);
                        String myFormat = "dd/MM/yy"; //Change as you need
                        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.FRANCE);
                        etEventDate.setText(sdf.format(myCalendar.getTime()));

                        mDay = selectedday;
                        mMonth = selectedmonth;
                        mYear = selectedyear;
                    }
                }, mYear, mMonth, mDay);
                //mDatePicker.setTitle("Select date");
                mDatePicker.show();
            }
        });
    }

    @OnClick(R.id.btn_submit)
    public void onGoing() {
        Intent intent = new Intent(this, DiningActivity.class);
        startActivity(intent);
    }

    public static void start(Context context) {
        Intent intent = new Intent(context, AddEventActivity.class);
        context.startActivity(intent);
    }

    @OnClick(R.id.iv_back)
    public void onClickBack() {
        onBackPressed();
    }

}