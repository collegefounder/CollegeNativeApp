package com.app.college.UserInterface.main.employee.empEvents.eventDetails;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.app.college.R;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by 123 on 08-06-2018.
 */

public class EventDetailsActivity extends AppCompatActivity {

    @BindView(R.id.tv_place)
    public TextView tvPlace;

    @BindView(R.id.tv_date)
    public TextView tvDate;

    @BindView(R.id.tv_time)
    public TextView tvTime;

    @BindView(R.id.btn_going)
    public Button btnGoing;
    @BindView(R.id.iv_back)
    public ImageView ivBack;
    @BindView(R.id.tv_header)
    public TextView tvHeader;
    @BindView(R.id.iv_add)
    public ImageView ivAddEvent;

    public static void start(Context context) {
        Intent intent = new Intent(context, EventDetailsActivity.class);
        context.startActivity(intent);
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_details);
        ButterKnife.bind(this);

        initViews();
    }

    private void initViews() {
        ivBack.setVisibility(View.VISIBLE);
        ivAddEvent.setVisibility(View.GONE);
        tvHeader.setText(getString(R.string.events_details));
    }

    @OnClick(R.id.btn_going)
    public void onGoing() {
    }

    @OnClick(R.id.iv_back)
    public void onClickBack() {
        onBackPressed();
    }
}
