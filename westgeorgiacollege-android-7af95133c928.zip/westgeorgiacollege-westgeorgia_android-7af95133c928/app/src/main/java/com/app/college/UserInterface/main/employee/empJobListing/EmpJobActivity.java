package com.app.college.UserInterface.main.employee.empJobListing;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.app.college.R;
import com.app.college.data.model.JobModel;
import com.app.college.ui.authenticate.base.BaseAuthenticateActivity;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;

public class EmpJobActivity extends BaseAuthenticateActivity implements JobAdapter.OnClickJobAndApplication {

    @BindView(R.id.iv_back)
    public ImageView ivBack;
    @BindView(R.id.tv_header)
    public TextView tvHeader;

    @BindView(R.id.rl_jobs)
    public RelativeLayout rlJobs;
    @BindView(R.id.rl_job_applications)
    public RelativeLayout rlJobApplications;
    @BindView(R.id.tv_jobs)
    public TextView tvJobs;
    @BindView(R.id.tv_job_applications)
    public TextView tvJobApplications;
    @BindView(R.id.iv_jobs)
    public ImageView ivJobs;
    @BindView(R.id.iv_job_applications)
    public ImageView ivJobApplications;
    @BindView(R.id.recycler_jobs)
    public RecyclerView rvJobs;

    JobAdapter jobAdapter;
    List<JobModel> jobModelList = new ArrayList<>();

    public static void start(Context context) {
        Intent intent = new Intent(context, EmpJobActivity.class);
        context.startActivity(intent);
    }

    @Override
    protected int getContentId() {
        return R.layout.activity_emp_job;
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        initViews();
        initAdapter();
        onJobsClick();
    }

    private void initViews() {
        ivBack.setVisibility(View.VISIBLE);
        tvHeader.setText(getString(R.string.jobs));
    }

    private void initAdapter() {

        jobAdapter = new JobAdapter(jobModelList, this, this);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        rvJobs.setLayoutManager(linearLayoutManager);
        rvJobs.setAdapter(jobAdapter);
    }

    @OnClick(R.id.rl_jobs)
    public void onJobsClick() {

        jobModelList.clear();
        for (int i = 0; i < 5; i++) {
            JobModel jobModel = new JobModel();
            jobModel.setJobTitle("Job Title");
            jobModel.setJobDescription("Job Description");
            jobModel.setJobLocation("Job Location");
            jobModel.setFrom("job");
            jobModelList.add(jobModel);
        }

        jobAdapter.notifyDataSetChanged();

        tvHeader.setText(getString(R.string.jobs));
        tvJobs.setTextColor(ContextCompat.getColor(this, R.color.white));
        rlJobs.setBackgroundColor(ContextCompat.getColor(this, R.color.selected_list));
        ivJobs.setVisibility(View.VISIBLE);

        tvJobApplications.setTextColor(ContextCompat.getColor(this, R.color.selected_list));
        rlJobApplications.setBackground(ContextCompat.getDrawable(this, R.drawable.rec_blue_border));
        ivJobApplications.setVisibility(View.GONE);
    }

    @OnClick(R.id.rl_job_applications)
    public void onJobApplicationsClick() {

        jobModelList.clear();
        for (int i = 0; i < 5; i++) {
            JobModel jobModel = new JobModel();
            jobModel.setName("Student Name");
            jobModel.setUserName("Lorem Iipsm");
            jobModel.setNumber("09090909090");
            jobModel.setFrom("app");
            jobModelList.add(jobModel);
        }

        jobAdapter.notifyDataSetChanged();

        tvHeader.setText(getString(R.string.resources));
        tvJobApplications.setTextColor(ContextCompat.getColor(this, R.color.white));
        rlJobApplications.setBackgroundColor(ContextCompat.getColor(this, R.color.selected_list));
        ivJobApplications.setVisibility(View.VISIBLE);

        tvJobs.setTextColor(ContextCompat.getColor(this, R.color.selected_list));
        rlJobs.setBackground(ContextCompat.getDrawable(this, R.drawable.rec_blue_border));
        ivJobs.setVisibility(View.GONE);

    }

    @Override
    public void onClickJobAndApplication(int position, JobModel jobModel) {

        if (jobModel.getFrom().equalsIgnoreCase("job")) {
            EmpJobDetailsActivity.start(this);
        } else if (jobModel.getFrom().equalsIgnoreCase("app")) {
            EmpJobApplicantDescActivity.start(this);
        }
    }

    @OnClick(R.id.iv_back)
    public void onClickBack() {
        onBackPressed();
    }
}
