package com.app.college.UserInterface.main.employee.empJobListing;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.app.college.R;
import com.app.college.ui.authenticate.base.BaseAuthenticateActivity;
import com.app.college.utils.ToastUtils;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * Created by 123 on 07-06-2018.
 */

public class EmpJobDetailsActivity extends BaseAuthenticateActivity {

    @BindView(R.id.iv_back)
    public ImageView ivBack;
    @BindView(R.id.tv_header)
    public TextView tvHeader;


    public static void start(Context context) {
        Intent intent = new Intent(context, EmpJobDetailsActivity.class);
        context.startActivity(intent);
    }

    @Override
    protected int getContentId() {
        return R.layout.activity_emp_job_details;
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        initViews();
    }

    private void initViews() {
        ivBack.setVisibility(View.VISIBLE);
        tvHeader.setText(getString(R.string.job_details));
    }

    @OnClick(R.id.iv_back)
    public void onClickBack() {
        onBackPressed();
    }

    @OnClick(R.id.btn_delete)
    public void onSubmit() {
        ToastUtils.shortToast(getString(R.string.under_development));
    }

    @OnClick(R.id.btn_edit)
    public void onClickEdit() {
        ToastUtils.shortToast(getString(R.string.under_development));
    }
}
