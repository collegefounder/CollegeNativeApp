package com.app.college.UserInterface.main.employee.empJobListing;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.app.college.R;
import com.app.college.data.model.JobModel;

import java.util.List;

public class JobAdapter extends RecyclerView.Adapter<JobAdapter.ViewHolder> {

    Context context;
    List<JobModel> jobModelList;
    OnClickJobAndApplication onClickJobAndApplication;

    public JobAdapter(List<JobModel> jobModelList, OnClickJobAndApplication onClickJobAndApplication, Context context) {
        this.jobModelList = jobModelList;
        this.context = context;
        this.onClickJobAndApplication = onClickJobAndApplication;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.emp_job_layout, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {

        if (jobModelList.get(position).getFrom().equalsIgnoreCase("job")) {
            holder.tvTitle.setText(jobModelList.get(position).getJobTitle());
            holder.tvLocation.setText(jobModelList.get(position).getJobLocation());
            holder.tvDesc.setText(jobModelList.get(position).getJobDescription());
        } else if (jobModelList.get(position).getFrom().equalsIgnoreCase("app")) {
            holder.tvTitle.setText(jobModelList.get(position).getName());
            holder.tvLocation.setText(jobModelList.get(position).getUserName());
            holder.tvDesc.setText(jobModelList.get(position).getNumber());
        }

        holder.rlJobPosted.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                onClickJobAndApplication.onClickJobAndApplication(position, jobModelList.get(position));
            }
        });
    }

    @Override
    public int getItemCount() {
        return jobModelList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        RelativeLayout rlJobPosted;
        TextView tvTitle, tvLocation, tvDesc;

        public ViewHolder(View itemView) {
            super(itemView);

            rlJobPosted = (RelativeLayout) itemView.findViewById(R.id.rl_jobs_posted);
            tvTitle = (TextView) itemView.findViewById(R.id.tv_company_name);
            tvLocation = (TextView) itemView.findViewById(R.id.tv_open_position);
            tvDesc = (TextView) itemView.findViewById(R.id.tv_phone_number);
        }
    }

    public interface OnClickJobAndApplication {

        void onClickJobAndApplication(int position, JobModel jobModel);
    }
}
