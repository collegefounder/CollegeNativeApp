package com.app.college.UserInterface.main.employee.empUploadJob;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.app.college.R;
import com.app.college.ui.authenticate.base.BaseAuthenticateActivity;
import butterknife.BindView;
import butterknife.OnClick;

public class EmpUploadJobActivity extends BaseAuthenticateActivity {

    @BindView(R.id.iv_back)
    public ImageView ivBack;
    @BindView(R.id.tv_header)
    public TextView tvHeader;
    public static void start(Context context) {
        Intent intent = new Intent(context, EmpUploadJobActivity.class);
        context.startActivity(intent);
    }

    @Override
    protected int getContentId() {
        return R.layout.activity_emp_upload_job;
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        initViews();
    }

    private void initViews() {
        ivBack.setVisibility(View.VISIBLE);
        tvHeader.setText(getString(R.string.upload_job));
    }

    @OnClick(R.id.btn_submit)
    public void onClickSubmit() {
//        Intent intent=new Intent(this, ChooseInstituteActivity.class);
//        startActivity(intent);
    }

    @OnClick(R.id.iv_back)
    public void onClickBack() {
        onBackPressed();
    }

}
