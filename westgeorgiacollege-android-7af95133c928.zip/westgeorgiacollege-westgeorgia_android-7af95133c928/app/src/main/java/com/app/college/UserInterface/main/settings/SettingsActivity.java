package com.app.college.UserInterface.main.settings;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.app.college.R;
import com.app.college.UserInterface.authenticate.login.LoginActivity;
import com.app.college.UserInterface.main.settings.myProfile.MyProfileActivity;
import com.app.college.utils.CommonMethods;
import com.app.college.utils.Constants;
import com.app.college.utils.YesNoDialogListener;
import com.app.college.utils.helpers.SharedPreferenceHelper;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by 123 on 08-06-2018.
 */

public class SettingsActivity extends AppCompatActivity implements YesNoDialogListener{

    @BindView(R.id.tv_header)
    public TextView tvHeader;
    @BindView(R.id.iv_back)
    public ImageView ivBack;
    @BindView(R.id.iv_settings)
    public ImageView ivSettings;
    @BindView(R.id.iv_share_location)
    public ImageView ivShareLocation;
    @BindView(R.id.iv_profile)
    public ImageView ivProfile;
    @BindView(R.id.iv_terms_conditions)
    public ImageView ivTermsConditions;
    @BindView(R.id.iv_contact_us)
    public ImageView ivContactus;
    @BindView(R.id.iv_logout)
    public ImageView ivLogout;
    private boolean shared;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        ButterKnife.bind(this);

        tvHeader.setText(getString(R.string.settings));
        ivBack.setVisibility(View.VISIBLE);
        ivSettings.setVisibility(View.GONE);
    }

    @OnClick(R.id.iv_back)
    public void onBackClick()
    {
        onBackPressed();
    }

    @OnClick(R.id.rl_share_location)
    public void onShareLocationClick(){
        if(shared){
            ivShareLocation.setImageResource(R.mipmap.ic_select_button);
            shared=false;
        }
        else{
            ivShareLocation.setImageResource(R.mipmap.ic_unselected_button);
            shared=true;
        }
    }
    @OnClick(R.id.rl_my_profile)
    public void onProfileClick()
    {
        Intent intent= new Intent(this,MyProfileActivity.class);
        startActivity(intent);
    }

    @OnClick(R.id.rl_contact_us)
    public void oncontact()
    {
        Intent intent= new Intent(this,ContactUsActivity.class);
        startActivity(intent);
    }

    @OnClick(R.id.rl_terms_conditions)
    public void onTerms()
    {
        Intent intent= new Intent(this,TermsConditionsActivity.class);
        startActivity(intent);
    }


    @OnClick(R.id.rl_logout)
    public void onlogout()
    {
        CommonMethods.yesNoDialog(Constants.LOGOUT, getString(R.string.logout),
                getString(R.string.logout_confirm), (YesNoDialogListener) this, this);
    }

    @Override
    public void yesClicked(String type) {
         new SharedPreferenceHelper(SettingsActivity.this).savePref(Constants.LOGED_IN, false);
        new SharedPreferenceHelper(SettingsActivity.this).savePref(Constants.EMAIL, null);
        //new SharedPreferenceHelper(SettingsActivity.this).clearAll();
        Intent logout = new Intent(this,LoginActivity.class);
        logout.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(logout);
        finish();
    }

    @Override
    public void noClicked(String type) {

    }
}