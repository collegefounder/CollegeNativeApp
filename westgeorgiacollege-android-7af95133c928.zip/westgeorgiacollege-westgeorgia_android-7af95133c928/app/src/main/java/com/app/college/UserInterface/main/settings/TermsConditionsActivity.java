package com.app.college.UserInterface.main.settings;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.app.college.R;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class TermsConditionsActivity extends AppCompatActivity {


    @BindView(R.id.iv_back)
    public ImageView ivBack;
    @BindView(R.id.tv_header)
    public TextView tvHeader;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_terms_conditions);

        ButterKnife.bind(this);
        ivBack.setVisibility(View.VISIBLE);
        tvHeader.setText(getString(R.string.terms_conditions));
    }
    @OnClick(R.id.iv_back)
    public void onBackClick()
    {
        onBackPressed();
    }
}
