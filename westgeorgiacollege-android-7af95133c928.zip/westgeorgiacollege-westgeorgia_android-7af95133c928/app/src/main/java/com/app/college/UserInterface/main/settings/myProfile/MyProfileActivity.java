package com.app.college.UserInterface.main.settings.myProfile;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.app.college.R;
import com.app.college.UserInterface.main.settings.myProfile.changePassword.ChangePasswordActivity;
import com.app.college.UserInterface.main.settings.myProfile.updateInfo.UpdateInfoActivity;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by 123 on 08-06-2018.
 */

public class MyProfileActivity extends AppCompatActivity {

    @BindView(R.id.tv_header)
    public TextView tvHeader;
    @BindView(R.id.iv_back)
    public ImageView ivBack;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_myprofile);
        ButterKnife.bind(this);

        tvHeader.setText(getString(R.string.my_profile));
        ivBack.setVisibility(View.VISIBLE);
    }

    @OnClick(R.id.iv_back)
    public void onBackClick()
    {
        onBackPressed();
    }

    @OnClick(R.id.btn_edit)
    public void onClickEdit()
    {
        Intent intent= new Intent(this,UpdateInfoActivity.class);
        startActivity(intent);
    }



    @OnClick(R.id.rl_change_password)
    public void onClickpass()
    {
        Intent intent= new Intent(this,ChangePasswordActivity.class);
        startActivity(intent);
    }
}
