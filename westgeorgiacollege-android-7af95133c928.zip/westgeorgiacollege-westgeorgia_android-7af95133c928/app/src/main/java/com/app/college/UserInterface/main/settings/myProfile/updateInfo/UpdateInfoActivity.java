package com.app.college.UserInterface.main.settings.myProfile.updateInfo;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


import com.app.college.R;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by 123 on 08-06-2018.
 */

public class UpdateInfoActivity extends AppCompatActivity {

    @BindView(R.id.et_name)
    public EditText etName;

    @BindView(R.id.et_phone_number)
    public EditText etPhoneNumber;

    @BindView(R.id.et_email_address)
    public EditText etEmailAddress;

    @BindView(R.id.et_address)
    public EditText etAddress;

    @BindView(R.id.btn_save)
    public Button btnSave;

    @BindView(R.id.tv_header)
    public TextView tvHeader;
    @BindView(R.id.iv_back)
    public ImageView ivBack;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_info);
        ButterKnife.bind(this);
        tvHeader.setText(getString(R.string.update_info));
        ivBack.setVisibility(View.VISIBLE);
    }

    @OnClick(R.id.iv_back)
    public void onBackClick() {
        onBackPressed();
    }
    @OnClick(R.id.btn_save)
    public void onSaveClick()
    {
        Toast.makeText(this,"under development",Toast.LENGTH_SHORT).show();
    }
}
