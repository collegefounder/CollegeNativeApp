package com.app.college.UserInterface.main.students;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.app.college.R;
import com.app.college.UserInterface.main.students.news.NewsActivity;
import com.app.college.UserInterface.main.students.directory.DirectoryActivity;
import com.app.college.UserInterface.main.settings.SettingsActivity;
import com.app.college.ui.authenticate.base.BaseAuthenticateActivity;
import com.app.college.UserInterface.main.students.myCourses.myCourse.MyCoursesActivity;
import com.app.college.UserInterface.main.students.registerPayForCourse.RegisterPayCourseActivity;
import com.app.college.UserInterface.main.students.tours.ToursActivity;
import com.app.college.UserInterface.main.students.digitalCampus.DigitalCampusActivity;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * Created by 123 on 06-06-2018.
 */

public class HomeActivity extends BaseAuthenticateActivity {

    @BindView(R.id.tv_header)
    public TextView tvHeader;
    @BindView(R.id.iv_back)
    public ImageView ivBack;
    @BindView(R.id.iv_settings)
    public ImageView ivSettings;

    @Override
    protected int getContentId() {
        return R.layout.activity_home;
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ivBack.setVisibility(View.GONE);
        tvHeader.setText(getString(R.string.home));
        ivSettings.setVisibility(View.VISIBLE);
    }

    @OnClick(R.id.iv_back)
    public void onBackClick(){
        onBackPressed();
    }

    @OnClick(R.id.rl_mycourses)
    public void onMyCourses()
    {
        Intent intent= new Intent(this,MyCoursesActivity.class);
        startActivity(intent);
    }

    @OnClick(R.id.rl_register)
    public void onRegister()
    {
        Intent intent= new Intent(this,RegisterPayCourseActivity.class);
        startActivity(intent);
    }

    @OnClick(R.id.rl_news)
    public void onNewsClick(){
        Intent intent= new Intent(this,NewsActivity.class);
        startActivity(intent);
    }

    @OnClick(R.id.ll_digital_campus)
    public void onDigitalCampusClick(){
        Intent intent= new Intent(this,DigitalCampusActivity.class);
        startActivity(intent);
    }
    @OnClick(R.id.ll_directory)
    public void onDirectoryClick(){
        Intent intent= new Intent(this,DirectoryActivity.class);
        startActivity(intent);
    }
    @OnClick(R.id.ll_tours)
    public void onToursClick(){
        Intent intent= new Intent(this,ToursActivity.class);
        startActivity(intent);
    }

    @OnClick(R.id.iv_settings)
    public void onSettingsClick(){
        Intent intent= new Intent(this,SettingsActivity.class);
        startActivity(intent);
    }
}
