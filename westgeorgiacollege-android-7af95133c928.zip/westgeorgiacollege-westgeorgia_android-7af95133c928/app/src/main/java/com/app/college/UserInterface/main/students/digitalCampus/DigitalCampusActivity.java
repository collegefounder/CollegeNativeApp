package com.app.college.UserInterface.main.students.digitalCampus;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.app.college.R;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by 123 on 07-06-2018.
 */

public class DigitalCampusActivity extends AppCompatActivity {
    @BindView(R.id.rv_digital)
    public RecyclerView rvDigital;

    String[] campusServicesList;
    private List<String> digitalList = new ArrayList<>();
    @BindView(R.id.tv_header)
    public TextView tvHeader;
    @BindView(R.id.iv_back)
    public ImageView ivBack;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_digital_campus);
        ButterKnife.bind(this);
//        initList();

        tvHeader.setText(getString(R.string.digital_campus));
        ivBack.setVisibility(View.VISIBLE);

        campusServicesList=getResources().getStringArray(R.array.digital_campus_list);
        rvDigital.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,true));
        DigitalCampusAdapter digitalCampusAdapter = new DigitalCampusAdapter(this, campusServicesList);
        rvDigital.setAdapter(digitalCampusAdapter);

    }

    private void initList() {
        digitalList.add("Carrer Services");
        digitalList.add("Jobs Posted");
        digitalList.add("Residence Life");
    }
    @OnClick(R.id.iv_back)
    public void onBackClick(){
        onBackPressed();
    }
}
