package com.app.college.UserInterface.main.students.digitalCampus;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.app.college.R;
import com.app.college.UserInterface.main.employee.empEvents.EmpEventsActivity;
import com.app.college.UserInterface.main.students.digitalCampus.dining.DiningActivity;
import com.app.college.UserInterface.main.students.digitalCampus.resources.ResourcesActivity;
import com.app.college.UserInterface.main.students.digitalCampus.social.SocialActivity;
import com.app.college.UserInterface.main.students.digitalCampus.careerServices.CarrerServicesActivity;
import com.app.college.UserInterface.main.students.digitalCampus.fafsaDetails.FafsaDetailsActivity;
import com.app.college.UserInterface.main.students.digitalCampus.jobsPosted.JobsPostedActivity;
import com.app.college.UserInterface.main.students.digitalCampus.residenceLife.ResidenceLifeActivity;


/**
 * Created by 123 on 07-06-2018.
 */

public class DigitalCampusAdapter extends RecyclerView.Adapter<DigitalCampusAdapter.ViewHolder> {
    Context context;
    String[] campusServices;

    public DigitalCampusAdapter(Context context, String[] campusServices) {
        this.context = context;
        this.campusServices = campusServices;
    }

    @Override
    public DigitalCampusAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_digital_campus, null);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(DigitalCampusAdapter.ViewHolder holder, final int position) {
        holder.tvOne.setText(campusServices[position]);

        holder.tvOne.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (campusServices[position].equalsIgnoreCase("career services")) {
                    Intent intent = new Intent(context, CarrerServicesActivity.class);
                    context.startActivity(intent);

                } else if (campusServices[position].equalsIgnoreCase("Jobs Posted")) {
                    Intent intent = new Intent(context, JobsPostedActivity.class);
                    context.startActivity(intent);
                } else if (campusServices[position].equalsIgnoreCase("Residence Life")) {
                    Intent intent = new Intent(context, ResidenceLifeActivity.class);
                    context.startActivity(intent);
                }
                else if (campusServices[position].equalsIgnoreCase("FAFSA")) {
                    Intent intent = new Intent(context, FafsaDetailsActivity.class);
                    context.startActivity(intent);
                }
                else if (campusServices[position].equalsIgnoreCase("Events")) {
                    Intent intent = new Intent(context, EmpEventsActivity.class);
                    context.startActivity(intent);
                }
                else if (campusServices[position].equalsIgnoreCase("Dining")) {
                    Intent intent = new Intent(context, DiningActivity.class);
                    context.startActivity(intent);
                }
                else if (campusServices[position].equalsIgnoreCase("Resources")) {
                    Intent intent = new Intent(context, ResourcesActivity.class);
                    context.startActivity(intent);
                }
                else if (campusServices[position].equalsIgnoreCase("Social")) {
                    Intent intent = new Intent(context, SocialActivity.class);
                    context.startActivity(intent);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return campusServices.length;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvOne;

        public ViewHolder(View itemView) {
            super(itemView);

            tvOne = itemView.findViewById(R.id.tv_one);

        }
    }
}
