package com.app.college.UserInterface.main.students.digitalCampus.dining;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.app.college.R;
import com.app.college.UserInterface.main.students.digitalCampus.dining.addRestaurant.AddRestaurantActivity;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by 123 on 08-06-2018.
 */

public class DiningActivity extends AppCompatActivity {

    @BindView(R.id.iv_back)
    public ImageView ivBack;
    @BindView(R.id.tv_header)
    public TextView tvHeader;
    @BindView(R.id.iv_add)
    public ImageView ivAddEvent;

    @BindView(R.id.recycler_view)
    public RecyclerView rvDining;

    List<String> restrauntNames= new ArrayList<>();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dining);
        ButterKnife.bind(this);

        ivBack.setVisibility(View.VISIBLE);
        ivAddEvent.setVisibility(View.VISIBLE);
        tvHeader.setText(getString(R.string.dining));

        initRestraunt();
        rvDining.setLayoutManager(new LinearLayoutManager(this));
        DiningAdapter diningAdapter= new DiningAdapter(this,restrauntNames);
        rvDining.setAdapter(diningAdapter);
    }

    private void initRestraunt() {
        for(int i=0; i<5; i++)
        {
            restrauntNames.add("Restaurant Name");
        }
    }

    @OnClick(R.id.iv_add)
    public void onAddClick(){
        Intent intent=new Intent(this, AddRestaurantActivity.class);
        startActivity(intent);
    }
    @OnClick(R.id.iv_back)
    public void onBackClick(){
        onBackPressed();
    }
}