package com.app.college.UserInterface.main.students.digitalCampus.dining;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.app.college.R;
import com.app.college.UserInterface.main.students.digitalCampus.dining.restaurantDetails.RestaurantDetails;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by 123 on 08-06-2018.
 */

public class DiningAdapter extends RecyclerView.Adapter<DiningAdapter.DiningView> {

    Context context;
    List<String> restrauntNames= new ArrayList<>();

    public DiningAdapter(Context context, List<String> restrauntNames)
    {
        this.context=context;
        this.restrauntNames=restrauntNames;
    }

    @Override
    public DiningView onCreateViewHolder(ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_dining,null);
        return new DiningView(view);
    }

    @Override
    public void onBindViewHolder(DiningView holder, int position) {
        holder.tvRestrauntName.setText(restrauntNames.get(position).toString());

        holder.rlDining.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(context,RestaurantDetails.class);
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return restrauntNames.size();
    }

    public class DiningView extends RecyclerView.ViewHolder {
        TextView tvRestrauntName, tvLocation;
        RelativeLayout rlDining;

        public DiningView(View itemView) {
            super(itemView);

            tvRestrauntName=itemView.findViewById(R.id.tv_restraunt_name);
            tvLocation=itemView.findViewById(R.id.tv_location);
            rlDining=itemView.findViewById(R.id.rl_dining);

        }
    }
}