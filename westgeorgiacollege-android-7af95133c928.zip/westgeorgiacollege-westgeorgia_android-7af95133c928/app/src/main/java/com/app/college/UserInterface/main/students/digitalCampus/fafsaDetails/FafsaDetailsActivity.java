package com.app.college.UserInterface.main.students.digitalCampus.fafsaDetails;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.app.college.R;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by 123 on 08-06-2018.
 */

public class FafsaDetailsActivity extends AppCompatActivity {

    @BindView(R.id.tv_details)
    public TextView tvDetails;
    @BindView(R.id.tv_header)
    public TextView tvHeader;
    @BindView(R.id.iv_back)
    public ImageView ivBack;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fafsa_details);
        ButterKnife.bind(this);

        ivBack.setVisibility(View.VISIBLE);
        tvHeader.setText(getString(R.string.fafsa_header));
    }


    @OnClick(R.id.iv_back)
    public void onBackClick()
    {
        onBackPressed();
    }
}
