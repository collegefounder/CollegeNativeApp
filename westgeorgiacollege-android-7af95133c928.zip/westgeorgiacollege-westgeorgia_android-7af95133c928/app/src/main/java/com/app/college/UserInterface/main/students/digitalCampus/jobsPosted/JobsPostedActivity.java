package com.app.college.UserInterface.main.students.digitalCampus.jobsPosted;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.app.college.R;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by 123 on 07-06-2018.
 */

public class JobsPostedActivity extends AppCompatActivity {
    @BindView(R.id.rv_jobs_posted)
    public RecyclerView rvJobsPosted;
    @BindView(R.id.tv_header)
    public TextView tvHeader;
    @BindView(R.id.iv_back)
    public ImageView ivBack;

    private List<String> companyNamesList= new ArrayList<>();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jobs_posted);
        ButterKnife.bind(this);

        tvHeader.setText(getString(R.string.jobs_posted));
        ivBack.setVisibility(View.VISIBLE);

        initializeList();
        rvJobsPosted.setLayoutManager(new LinearLayoutManager(this));
        JobsPostedAdapter jobsPostedAdapter= new JobsPostedAdapter(this,companyNamesList);
        rvJobsPosted.setAdapter(jobsPostedAdapter);
    }

    private void initializeList() {
        for (int i=0; i<5;i++)
        {
            companyNamesList.add("Company Name");
        }
    }

    @OnClick(R.id.iv_back)
    public void onBackClick(){
        onBackPressed();
    }
}
