package com.app.college.UserInterface.main.students.digitalCampus.jobsPosted;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.app.college.R;
import com.app.college.UserInterface.main.students.digitalCampus.jobsPosted.jobDetails.JobsDetailsActivity;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by 123 on 07-06-2018.
 */

public class JobsPostedAdapter extends RecyclerView.Adapter<JobsPostedAdapter.MyViewHolder> {
    Context context;
    private List<String> companyNamesList= new ArrayList<>();

    public  JobsPostedAdapter(Context context, List<String> companyNamesList)
    {
        this.context= context;
        this.companyNamesList= companyNamesList;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_jobs_posted,null);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        holder.tvCompanyName.setText(companyNamesList.get(position).toString());

        holder.rlJobsPosted.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(context,JobsDetailsActivity.class);
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return companyNamesList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView tvCompanyName, tvOpenPosition, tvPhoneNumber;
        RelativeLayout rlJobsPosted;

        public MyViewHolder(View itemView) {
            super(itemView);
            tvCompanyName= itemView.findViewById(R.id.tv_company_name);
            tvOpenPosition= itemView.findViewById(R.id.tv_open_position);
            tvPhoneNumber= itemView.findViewById(R.id.tv_phone_number);
            rlJobsPosted=itemView.findViewById(R.id.rl_jobs_posted);
        }
    }
}