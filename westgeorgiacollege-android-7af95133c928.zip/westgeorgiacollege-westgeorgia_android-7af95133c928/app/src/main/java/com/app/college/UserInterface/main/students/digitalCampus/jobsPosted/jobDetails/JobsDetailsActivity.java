package com.app.college.UserInterface.main.students.digitalCampus.jobsPosted.jobDetails;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.app.college.R;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by 123 on 07-06-2018.
 */

public class JobsDetailsActivity extends AppCompatActivity {

    @BindView(R.id.tv_company_name)
    public TextView tvCompanyName;
    @BindView(R.id.tv_developer)
    public TextView tvDeveloper;
    @BindView(R.id.tv_address_details)
    public TextView tvAddressDetails;
    @BindView(R.id.tv_email)
    public TextView tvEmail;

    @BindView(R.id.tv_phone)
    public TextView tvPhone;

    @BindView(R.id.btn_submit)
    public Button btnSubmit;
    @BindView(R.id.tv_header)
    public TextView tvHeader;
    @BindView(R.id.iv_back)
    public ImageView ivBack;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_job_details);
        ButterKnife.bind(this);

        ivBack.setVisibility(View.VISIBLE);
        tvHeader.setText(getString(R.string.job_details));

    }

    @OnClick(R.id.btn_submit)
    public void onSubmit() {
    }
    @OnClick(R.id.iv_back)
    public void onBackClick(){
        onBackPressed();
    }
}
