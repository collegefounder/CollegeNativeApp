package com.app.college.UserInterface.main.students.digitalCampus.resources;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.app.college.R;
import com.app.college.UserInterface.main.students.digitalCampus.resources.nearByStudents.NearbyStudentsFragment;
import com.app.college.UserInterface.main.students.digitalCampus.resources.webMD.WebMdFragment;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by 123 on 08-06-2018.
 */

public class ResourcesActivity extends AppCompatActivity {

    @BindView(R.id.rl_web_md)
    public RelativeLayout rlWebmd;
    @BindView(R.id.rl_nearby)
    public RelativeLayout rlNearbyStudent;
    @BindView(R.id.tv_web_md)
    public TextView tvWebmd;
    @BindView(R.id.tv_nearby)
    public TextView tvNearbyStudents;
    @BindView(R.id.iv_web_md)
    public ImageView ivArrowWebmd;
    @BindView(R.id.iv_nearby)
    public ImageView ivArrowNearby;
    @BindView(R.id.frame_layout)
    public FrameLayout frameLayout;
    @BindView(R.id.tv_header)
    public TextView tvHeader;
    @BindView(R.id.iv_back)
    public ImageView ivBack;

    private Fragment fragment= null;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resources);
        ButterKnife.bind(this);

        ivBack.setVisibility(View.VISIBLE);
        tvHeader.setText(getString(R.string.resources));

        switchFragments(new WebMdFragment());
    }


    @OnClick(R.id.rl_web_md)
    public void onClickWebmd()
    {

        rlWebmd.setBackgroundResource(R.color.selected_list);
        tvWebmd.setTextColor(ContextCompat.getColor(this, R.color.white));
        ivArrowWebmd.setVisibility(View.VISIBLE);
        rlNearbyStudent.setBackgroundResource(R.drawable.rec_blue_border);
        tvNearbyStudents.setTextColor(ContextCompat.getColor(this, R.color.selected_list));
        ivArrowNearby.setVisibility(View.GONE);

        switchFragments(new WebMdFragment());
    }


    @OnClick(R.id.rl_nearby)
    public void onClickNearby()
    {
        rlNearbyStudent.setBackgroundResource(R.color.selected_list);
        tvNearbyStudents.setTextColor(ContextCompat.getColor(this, R.color.white));
        ivArrowNearby.setVisibility(View.VISIBLE);
        rlWebmd.setBackgroundResource(R.drawable.rec_blue_border);
        tvWebmd.setTextColor(ContextCompat.getColor(this, R.color.selected_list));
        ivArrowWebmd.setVisibility(View.GONE);

        switchFragments(new NearbyStudentsFragment());

    }

    private void switchFragments(Fragment fragment){
        FragmentManager fragmentManager= getSupportFragmentManager();
        FragmentTransaction fragmentTransaction= fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.frame_layout,fragment);
        fragmentTransaction.commit();
    }

    @OnClick(R.id.iv_back)
    public void onBackClick(){
        onBackPressed();
    }
}
