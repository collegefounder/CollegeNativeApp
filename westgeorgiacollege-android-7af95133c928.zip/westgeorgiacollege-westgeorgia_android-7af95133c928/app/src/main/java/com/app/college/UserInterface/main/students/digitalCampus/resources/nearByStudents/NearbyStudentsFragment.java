package com.app.college.UserInterface.main.students.digitalCampus.resources.nearByStudents;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.app.college.R;

import butterknife.ButterKnife;

/**
 * Created by 123 on 08-06-2018.
 */

public class NearbyStudentsFragment extends Fragment {


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view= inflater.inflate(R.layout.fragment_nearby_students,container,false);
        ButterKnife.bind(this,view);
        return  view;
    }
}
