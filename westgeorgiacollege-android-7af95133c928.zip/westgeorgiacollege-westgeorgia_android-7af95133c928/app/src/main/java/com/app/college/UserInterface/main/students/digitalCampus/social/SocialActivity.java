package com.app.college.UserInterface.main.students.digitalCampus.social;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.app.college.R;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by 123 on 08-06-2018.
 */

public class SocialActivity extends AppCompatActivity {

    @BindView(R.id.iv_facebook)
    public ImageView ivFacebook;

    @BindView(R.id.iv_twitter)
    public ImageView ivTwitter;

    @BindView(R.id.iv_LinkedIn)
    public ImageView ivLinkedIn;

    @BindView(R.id.iv_snapchat)
    public ImageView ivSnapchat;

    @BindView(R.id.iv_instagram)
    public ImageView ivInstagram;
    @BindView(R.id.tv_header)
    public TextView tvHeader;
    @BindView(R.id.iv_back)
    public ImageView ivBack;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_social);
        ButterKnife.bind(this);

        tvHeader.setText(getString(R.string.social));
        ivBack.setVisibility(View.VISIBLE);
    }

    @OnClick(R.id.iv_back)
    public void onBackClick() {
        onBackPressed();
    }

}
