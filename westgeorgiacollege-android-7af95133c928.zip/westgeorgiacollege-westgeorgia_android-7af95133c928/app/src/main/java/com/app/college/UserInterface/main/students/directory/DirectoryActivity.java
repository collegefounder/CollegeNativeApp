package com.app.college.UserInterface.main.students.directory;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.app.college.R;
import com.app.college.data.model.DirectoryModel;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by 123 on 08-06-2018.
 */

public class DirectoryActivity extends AppCompatActivity {

    @BindView(R.id.rv_directory)
    public RecyclerView rvDirectory;

    @BindView(R.id.btn_submit)
    public Button btnSubmit;
    @BindView(R.id.tv_header)
    public TextView tvHeader;
    @BindView(R.id.iv_back)
    public ImageView ivBack;
    List<DirectoryModel> nameList= new ArrayList<>();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_directory);
        ButterKnife.bind(this);
        tvHeader.setText(getString(R.string.directory));
        ivBack.setVisibility(View.VISIBLE);

        initNames();
        rvDirectory.setLayoutManager(new LinearLayoutManager(this));
        DirectoryAdapter directoryAdapter= new DirectoryAdapter(this,nameList);
        rvDirectory.setAdapter(directoryAdapter);
    }

    private void initNames() {
        for(int i= 0;i<5;i++)
        {
            DirectoryModel directoryModel=new DirectoryModel();
            directoryModel.setName("name");
            directoryModel.setSelected(false);
            nameList.add(directoryModel);
        }
    }
    @OnClick(R.id.iv_back)
    public void onBackClick()
    {
        onBackPressed();
    }
}
