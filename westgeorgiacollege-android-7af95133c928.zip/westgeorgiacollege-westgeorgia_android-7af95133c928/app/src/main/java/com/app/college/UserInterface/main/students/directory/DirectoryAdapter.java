package com.app.college.UserInterface.main.students.directory;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.app.college.R;
import com.app.college.data.model.DirectoryModel;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by 123 on 08-06-2018.
 */

public class DirectoryAdapter extends RecyclerView.Adapter<DirectoryAdapter.DirectoryView> {
    Context context;
    List<DirectoryModel> nameList= new ArrayList<>();

    public DirectoryAdapter(Context context, List<DirectoryModel> nameList)
    {
        this.context=context;
        this.nameList=nameList;
    }

    @Override
    public DirectoryView onCreateViewHolder(ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_directory,null);
        return new DirectoryView(view);
    }

    @Override
    public void onBindViewHolder(final DirectoryView holder, final int position) {
        holder.tvName.setText(nameList.get(position).getName());

        holder.ivSelect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(!nameList.get(position).isSelected()){
                    holder.ivSelect.setImageResource(R.mipmap.ic_check_box);
                    nameList.get(position).setSelected(true);
                }
                else{
                    holder.ivSelect.setImageResource(R.mipmap.ic_uncheckbox);
                    nameList.get(position).setSelected(false);
                }
                notifyDataSetChanged();
            }
        });

    }

    @Override
    public int getItemCount() {
        return nameList.size();
    }

    public class DirectoryView extends RecyclerView.ViewHolder {

        TextView tvName,tvEmailAddress, tvNumber;
        ImageView ivSelect;
        public DirectoryView(View itemView) {
            super(itemView);

            tvName= itemView.findViewById(R.id.tv_name);
            tvEmailAddress=itemView.findViewById(R.id.tv_email_address);
            tvNumber=itemView.findViewById(R.id.tv_number);
            ivSelect=itemView.findViewById(R.id.iv_check);
        }
    }
}
