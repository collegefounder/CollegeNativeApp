package com.app.college.UserInterface.main.students.myCourses.courseDetails;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.app.college.R;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by 123 on 07-06-2018.
 */

public class CoursesDetailsOrderTranscriptActivity extends AppCompatActivity {

    @BindView(R.id.tv_header)
    public TextView tvHeader;
    @BindView(R.id.iv_back)
    public ImageView ivBack;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_coursesdetails_transcript);
        ButterKnife.bind(this);

        ivBack.setVisibility(View.VISIBLE);
        tvHeader.setText(getString(R.string.course_details));
    }

    @OnClick(R.id.iv_back)
    public void onBackClick()
    {
        onBackPressed();
    }

    @OnClick(R.id.btn_order_transcript)
    public  void onClickOrder()
    {
        Intent intent= new Intent(this, OrderTranscriptActivity.class);
        startActivity(intent);

    }
}
