package com.app.college.UserInterface.main.students.myCourses.myCourse;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.app.college.R;
import com.app.college.UserInterface.main.students.myCourses.courseDetails.CoursesDetailsOrderTranscriptActivity;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by 123 on 07-06-2018.
 */

public class MyCoursesActivity extends AppCompatActivity {

    @BindView(R.id.rv_medical)
    public RecyclerView rvMedical;
    @BindView(R.id.tv_header)
    public TextView tvHeader;
    @BindView(R.id.iv_back)
    public ImageView ivBack;

    private List<String> coursename= new ArrayList<>();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mycourses);
        ButterKnife.bind(this);

        tvHeader.setText(getString(R.string.my_courses));
        ivBack.setVisibility(View.VISIBLE);

        initialize();
        rvMedical.setLayoutManager(new LinearLayoutManager(this));
        MyCoursesAdapter myCoursesAdapter= new MyCoursesAdapter(this,coursename);
        rvMedical.setAdapter(myCoursesAdapter);
    }

    private void initialize() {
        for(int i=0; i<5;i++)
        {
            coursename.add("Medical");
        }

    }

    @OnClick(R.id.btn_submit)
    public  void onSubmit()
    {
        Intent intent= new Intent(this,CoursesDetailsOrderTranscriptActivity.class);
        startActivity(intent);
    }

    @OnClick(R.id.iv_back)
    public void onBackClick(){
        onBackPressed();
    }
}
