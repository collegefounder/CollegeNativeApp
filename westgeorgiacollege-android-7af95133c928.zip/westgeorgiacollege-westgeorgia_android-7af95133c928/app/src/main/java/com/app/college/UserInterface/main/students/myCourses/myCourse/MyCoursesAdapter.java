package com.app.college.UserInterface.main.students.myCourses.myCourse;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.app.college.R;
import com.app.college.UserInterface.main.students.myCourses.courseDetails.CoursesDetailsOrderTranscriptActivity;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by 123 on 07-06-2018.
 */

public class MyCoursesAdapter extends RecyclerView.Adapter<MyCoursesAdapter.MyViewHolder> {
    Context context;
    List<String> coursename= new ArrayList<>();

    public MyCoursesAdapter(Context context, List<String> coursename)
    {
        this.context=context;
        this.coursename= coursename;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_mycourses,null);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        holder.tvMedical.setText(coursename.get(position).toString());
        holder.rlCourses.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(context, CoursesDetailsOrderTranscriptActivity.class);
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return coursename.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView tvMedical,tvMedicalDetail;
        RelativeLayout rlCourses;

        public MyViewHolder(View itemView) {
            super(itemView);

            rlCourses=itemView.findViewById(R.id.rl_all_courses);
            tvMedical= itemView.findViewById(R.id.tv_medical);
            tvMedicalDetail= itemView.findViewById(R.id.tv_medical_detail);
        }
    }
}
