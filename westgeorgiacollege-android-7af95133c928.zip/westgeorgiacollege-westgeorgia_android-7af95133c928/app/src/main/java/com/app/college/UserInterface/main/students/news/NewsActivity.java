package com.app.college.UserInterface.main.students.news;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.app.college.R;
import com.app.college.UserInterface.main.students.news.admin.AdminFragment;
import com.app.college.UserInterface.main.students.news.westGeorgia.WestGeorgiaFragment;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by 123 on 07-06-2018.
 */

public class NewsActivity extends AppCompatActivity {

    @BindView(R.id.tv_header)
    public TextView tvHeader;
    @BindView(R.id.iv_back)
    public ImageView ivBack;

    @BindView(R.id.rl_west_georgia)
    public RelativeLayout rlWestGeorgia;
    @BindView(R.id.rl_admin)
    public RelativeLayout rlAdmin;
    @BindView(R.id.iv_west_georgia)
    public ImageView ivDownArrowGeorgia;
    @BindView(R.id.iv_admin)
    public  ImageView ivDownArrowAdmin;
    @BindView(R.id.frame_layout)
    public FrameLayout frameLayout;
    @BindView(R.id.tv_west_georgia)
    public TextView tvWestGeorgia;
    @BindView(R.id.tv_admin)
    public TextView tvAdmin;

    private Fragment fragment= null;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news);
        ButterKnife.bind(this);
        ivBack.setVisibility(View.VISIBLE);
        tvHeader.setText(getString(R.string.news));

        switchFragments(new WestGeorgiaFragment());
    }

    @OnClick(R.id.iv_back)
    public void onBackClick()
    {
        onBackPressed();
    }

    @OnClick(R.id.rl_west_georgia)
    public void onWestgeorgiaClick()
    {
        rlWestGeorgia.setBackgroundResource(R.color.selected_list);
        tvWestGeorgia.setTextColor(ContextCompat.getColor(this, R.color.white));
        ivDownArrowGeorgia.setVisibility(View.VISIBLE);
        rlAdmin.setBackgroundResource(R.drawable.rec_blue_border);
        tvAdmin.setTextColor(ContextCompat.getColor(this, R.color.selected_list));
        ivDownArrowAdmin.setVisibility(View.GONE);

        switchFragments(new WestGeorgiaFragment());
    }


    @OnClick(R.id.rl_admin)
    public void onAdminClick()
    {
        rlAdmin.setBackgroundResource(R.color.selected_list);
        tvAdmin.setTextColor(ContextCompat.getColor(this, R.color.white));
        ivDownArrowAdmin.setVisibility(View.VISIBLE);
        rlWestGeorgia.setBackgroundResource(R.drawable.rec_blue_border);
        tvWestGeorgia.setTextColor(ContextCompat.getColor(this, R.color.selected_list));
        ivDownArrowGeorgia.setVisibility(View.GONE);

        switchFragments(new AdminFragment());

    }

    private void switchFragments(Fragment fragment){
        FragmentManager fragmentManager= getSupportFragmentManager();
        FragmentTransaction fragmentTransaction= fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.frame_layout,fragment);
        fragmentTransaction.commit();
    }
}
