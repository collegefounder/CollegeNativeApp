package com.app.college.UserInterface.main.students.news.admin;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.app.college.R;
import com.app.college.UserInterface.main.students.news.newsDescription.NewsDescriptionActivity;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by 123 on 07-06-2018.
 */

public class AdminAdapter extends RecyclerView.Adapter<AdminAdapter.AdminView> {
    Context context;
    List<String> adminList= new ArrayList<>();

    public AdminAdapter(Context context, List<String> adminList)
    {
        this.context= context;
        this.adminList=adminList;
    }

    @Override
    public AdminView onCreateViewHolder(ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_admin,null);
        return new AdminView(view);
    }

    @Override
    public void onBindViewHolder(AdminView holder, int position) {
        holder.tvNewsTitle.setText(adminList.get(position).toString());
        holder.rlAdmin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(context,NewsDescriptionActivity.class);
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return adminList.size();
    }

    public class AdminView extends RecyclerView.ViewHolder {
        TextView tvNewsTitle, tvNewsDescription;
        RelativeLayout rlAdmin;
        ImageView ivAdminImage;
        public AdminView(View itemView) {
            super(itemView);

            tvNewsTitle= itemView.findViewById(R.id.tv_news_title);
            tvNewsDescription= itemView.findViewById(R.id.tv_news_description);
            ivAdminImage= itemView.findViewById(R.id.iv_admin_image);
            rlAdmin=itemView.findViewById(R.id.rl_admin);
        }
    }
}
