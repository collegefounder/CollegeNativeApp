package com.app.college.UserInterface.main.students.news.admin;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.app.college.R;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by 123 on 07-06-2018.
 */

public class AdminFragment extends Fragment {

    @BindView(R.id.rv_admin)
    public RecyclerView rvAdmin;
    private List<String> adminList= new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_admin, container, false);
        ButterKnife.bind(this,view);

        initAdmin();

        rvAdmin.setLayoutManager(new LinearLayoutManager(getActivity()));
        AdminAdapter adminAdapter= new AdminAdapter(getActivity(),adminList);
        rvAdmin.setAdapter(adminAdapter);
        return  view;
    }

    private void initAdmin() {
         for(int i =0; i<5;i++)
         {
             adminList.add("News title");
         }
    }
}
