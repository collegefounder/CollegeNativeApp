package com.app.college.UserInterface.main.students.registerPayForCourse;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.app.college.R;
import com.app.college.UserInterface.main.students.registerPayForCourse.allCourses.AllCoursesFragment;
import com.app.college.UserInterface.main.students.registerPayForCourse.majors.MajorsFragment;
import com.app.college.data.getMajors.GetMajors;
import com.app.college.ui.authenticate.interactor.GetMajorsInteractor;
import com.app.college.ui.authenticate.intractorImpl.GetMajorsInteractorImpl;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by 123 on 07-06-2018.
 */

public class RegisterPayCourseActivity extends AppCompatActivity {

    @BindView(R.id.frame_layout)
    public FrameLayout frameLayout;
    @BindView(R.id.tv_header)
    public TextView tvHeader;
    @BindView(R.id.iv_back)
    public ImageView ivBack;
    @BindView(R.id.rl_majors)
    public RelativeLayout rlMajors;
    @BindView(R.id.tv_majors)
    public TextView tvMajors;
    @BindView(R.id.iv_majors)
    public ImageView ivMajors;
    @BindView(R.id.rl_courses)
    public RelativeLayout rlAllCourses;
    @BindView(R.id.tv_courses)
    public TextView tvAllCourses;
    @BindView(R.id.iv_courses)
    public ImageView ivAllCourses;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_paycourse);
        ButterKnife.bind(this);
        tvHeader.setText(getString(R.string.register_pay_for_course_header));
        ivBack.setVisibility(View.VISIBLE);
        switchFragments(new MajorsFragment());
    }

    @OnClick(R.id.rl_majors)
    public void onMajorsClick() {
        rlMajors.setBackgroundResource(R.color.selected_list);
        tvMajors.setTextColor(ContextCompat.getColor(this, R.color.white));
        ivMajors.setVisibility(View.VISIBLE);
        rlAllCourses.setBackgroundResource(R.drawable.rec_blue_border);
        tvAllCourses.setTextColor(ContextCompat.getColor(this, R.color.selected_list));
        ivAllCourses.setVisibility(View.GONE);

        switchFragments(new MajorsFragment());
    }

    @OnClick(R.id.rl_courses)
    public void onAllCoursesClick() {
        rlAllCourses.setBackgroundResource(R.color.selected_list);
        tvAllCourses.setTextColor(ContextCompat.getColor(this, R.color.white));
        ivAllCourses.setVisibility(View.VISIBLE);
        rlMajors.setBackgroundResource(R.drawable.rec_blue_border);
        ivMajors.setVisibility(View.GONE);
        tvMajors.setTextColor(ContextCompat.getColor(this, R.color.selected_list));

        switchFragments(new AllCoursesFragment());

    }

    private void switchFragments(Fragment fragment){
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.frame_layout,fragment);
        fragmentTransaction.commit();
    }

    @OnClick(R.id.iv_back)
    public void onBackClick(){
        onBackPressed();
    }

}
