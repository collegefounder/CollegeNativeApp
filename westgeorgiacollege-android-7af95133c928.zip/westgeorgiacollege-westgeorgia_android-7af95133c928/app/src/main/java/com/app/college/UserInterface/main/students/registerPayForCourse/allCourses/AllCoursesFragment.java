package com.app.college.UserInterface.main.students.registerPayForCourse.allCourses;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.app.college.R;
import com.app.college.UserInterface.main.students.registerPayForCourse.allCourses.adapter.CoursesFragmentAdapter;
import com.app.college.data.getAllCourses.GetAllCourse;
import com.app.college.data.getAllCourses.GetAllCourseDataList;
import com.app.college.ui.authenticate.interactor.GetCourseInteractor;
import com.app.college.ui.authenticate.intractorImpl.GetCourseInteractorImpl;
import com.app.college.utils.CommonMethods;
import com.app.college.utils.PaginationScrollListener;
import com.app.college.utils.ToastUtils;
import java.util.ArrayList;
import java.util.List;
import butterknife.ButterKnife;

/**
 * Created by 123 on 07-06-2018.
 */

public class AllCoursesFragment extends Fragment implements GetCourseInteractor.OnCompleteListener {

    private RecyclerView rvAllCourses;
    private List<GetAllCourseDataList> allCourses= new ArrayList<>();
    GetCourseInteractor interactor;
    private int TOTAL_RECORDS;
    private boolean isLastPage = false;
    private int currentPage = 0;
    private boolean isLoading = false;
    CoursesFragmentAdapter allCoursesFragmentAdapter;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_allcourses, container, false);
        ButterKnife.bind(this,view);
        rvAllCourses= view.findViewById(R.id.rv_allcourses);
        interactor=new GetCourseInteractorImpl(getActivity());
       // getAllCourses();
        return view;
    }
    @Override
    public void onResume() {
        super.onResume();
        allCourses.clear();
        currentPage = 0;
        getAllCourses();

    }


    private void initAdapter(List<GetAllCourseDataList> mList) {
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
        rvAllCourses.setLayoutManager(linearLayoutManager);
        allCoursesFragmentAdapter = new CoursesFragmentAdapter(mList,getActivity());
        rvAllCourses.setAdapter(allCoursesFragmentAdapter);
        rvAllCourses.addOnScrollListener(new PaginationScrollListener(linearLayoutManager) {
            @Override
            protected void loadMoreItems() {
                //getBookingList(currentBookingType);
                getAllCourses();
            }

            @Override
            public int getTotalPageCount() {
                return TOTAL_RECORDS;
            }

            @Override
            public boolean isLastPage() {
                return isLastPage;
            }

            @Override
            public boolean isLoading() {
                return isLoading;
            }
        });
    }

    private void getAllCourses() {
        isLoading = true;
        currentPage += 1;
        CommonMethods.showProgress(getActivity());
        interactor.getCourse(currentPage,this);
    }

    @Override
    public void onCourseSuccess(GetAllCourse response) {
        CommonMethods.hideProgress();
        if (response.getReturn() == 1) {

            TOTAL_RECORDS = response.getData().getTotal();
            if (currentPage == 1) {
                allCourses.addAll(response.getData().getData());
                initAdapter(allCourses);
                isLastPage = TOTAL_RECORDS <= allCoursesFragmentAdapter.getItemCount();
                // adpBooking.addLoadingFooter();
            } else {

                allCourses.addAll(response.getData().getData());
                initAdapter(allCourses);
                isLastPage = TOTAL_RECORDS <= allCoursesFragmentAdapter.getItemCount();
            }

            if (isLastPage) {
               // adpBooking.removeLoadingFooter();
            }
            isLoading = false;
        }
        else{
            ToastUtils.shortToast(response.getMessage());
        }
    }

    @Override
    public void onFailure(Throwable throwable) {
        CommonMethods.hideProgress();
    }
}
