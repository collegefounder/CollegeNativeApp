package com.app.college.UserInterface.main.students.registerPayForCourse.allCourses;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.app.college.R;
import com.app.college.UserInterface.main.students.registerPayForCourse.courseDetails.CoursesDetailsRegPayActivity;
import com.app.college.data.getAllCourses.GetAllCourseDataList;
import com.app.college.data.getMajorCourses.Datum;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by 123 on 07-06-2018.
 */

public class AllCoursesFragmentAdapter extends RecyclerView.Adapter<AllCoursesFragmentAdapter.MyViewHolder> {
    Context context;
    private List<GetAllCourseDataList> allCourses;

    public AllCoursesFragmentAdapter(Context context, List<GetAllCourseDataList> allCourses)
    {
        this.context=context;
        this.allCourses= allCourses;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_allcourses_fragment,null);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, final int position) {
        holder.tvMedical.setText(allCourses.get(position).getName());
        holder.tvDescription.setText(allCourses.get(position).getDescription());
        holder.tvCost.setText("$" + allCourses.get(position).getCost());
        holder.rlCourses.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(context,CoursesDetailsRegPayActivity.class);
                intent.putExtra("obj", (Serializable) allCourses.get(position));
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return allCourses.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView tvMedical;
        RelativeLayout rlCourses;
        TextView tvDescription;
        TextView tvCost;

        public MyViewHolder(View itemView) {
            super(itemView);
            tvMedical=itemView.findViewById(R.id.tv_medical);
            rlCourses=itemView.findViewById(R.id.rl_all_courses);
            tvDescription = itemView.findViewById(R.id.tv_medical_detail);
            tvCost = itemView.findViewById(R.id.tv_cost);
        }
    }
}
