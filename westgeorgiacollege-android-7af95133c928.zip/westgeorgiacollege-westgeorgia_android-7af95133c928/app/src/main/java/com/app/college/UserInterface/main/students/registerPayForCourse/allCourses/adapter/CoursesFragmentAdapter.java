package com.app.college.UserInterface.main.students.registerPayForCourse.allCourses.adapter;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.app.college.R;
import com.app.college.UserInterface.main.students.registerPayForCourse.courseDetails.CoursesDetailsRegPayActivity;
import com.app.college.UserInterface.main.students.registerPayForCourse.science.ScienceActivity;
import com.app.college.data.getAllCourses.GetAllCourseDataList;

import java.io.Serializable;
import java.util.List;

public class CoursesFragmentAdapter extends RecyclerView.Adapter<CoursesFragmentAdapter.ViewHolder> {

    private final List<GetAllCourseDataList> mList;
    private final Context context;

    public CoursesFragmentAdapter(List<GetAllCourseDataList> mList, Context context) {
        this.mList = mList;
        this.context = context;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_allcourses_fragment,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {

        holder.tvMedical.setText(mList.get(position).getName());
        holder.tvDescription.setText(mList.get(position).getDescription());
        holder.tvCost.setText("$" + mList.get(position).getCost());
        holder.rlCourses.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(context,CoursesDetailsRegPayActivity.class);
                intent.putExtra("obj", (Serializable) mList.get(position));
                context.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return mList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        TextView tvMedical;
        RelativeLayout rlCourses;
        TextView tvDescription;
        TextView tvCost;

        public ViewHolder(View itemView) {
            super(itemView);
            tvMedical=itemView.findViewById(R.id.tv_medical);
            rlCourses=itemView.findViewById(R.id.rl_all_courses);
            tvDescription = itemView.findViewById(R.id.tv_medical_detail);
            tvCost = itemView.findViewById(R.id.tv_cost);
        }
    }

}
