package com.app.college.UserInterface.main.students.registerPayForCourse.courseDetails;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import com.app.college.R;
import com.app.college.data.CommonResponse;
import com.app.college.data.getAllCourses.GetAllCourseDataList;
import com.app.college.data.getMajorCourses.Datum;
import com.app.college.ui.authenticate.interactor.SubmitCourseInteractor;
import com.app.college.ui.authenticate.intractorImpl.SubmitCourseInteractorImpl;
import com.app.college.utils.CommonMethods;
import com.app.college.utils.ToastUtils;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by 123 on 06-06-2018.
 */

public class CoursesDetailsRegPayActivity extends AppCompatActivity implements SubmitCourseInteractor.OnCompleteListener {

    @BindView(R.id.iv_back)
    public ImageView ivBack;
    @BindView(R.id.tv_header)
    public TextView tvHeader;
    @BindView(R.id.tv_medical_course)
    public TextView txtCourseName;
    @BindView(R.id.tv_course_hours)
    public TextView txtHours;
    @BindView(R.id.tv_years)
    public TextView txtYear;
    @BindView(R.id.tv_dollars)
    public TextView txtCost;
    @BindView(R.id.tv_description)
    public TextView txtDescription;
    @BindView(R.id.tv_syllabus)
    public TextView txtSyllabus;
    @BindView(R.id.btn_submit)
    public Button btnSubmit;
    SubmitCourseInteractor interactor;
    int courseId;
    GetAllCourseDataList model;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_courses_details);
        ButterKnife.bind(this);
        ivBack.setVisibility(View.VISIBLE);
        tvHeader.setText(getString(R.string.course_details));
        interactor = new SubmitCourseInteractorImpl(this);
        model = (GetAllCourseDataList)getIntent().getSerializableExtra("obj");
        setData();
    }


    public void setData(){
        if(model.getUserRegistered()==1)
        {
          btnSubmit.setText(getString(R.string.already_registered));
          btnSubmit.setClickable(false);
          btnSubmit.setEnabled(false);
        }

        txtCourseName.setText(model.getName());
        txtHours.setText(model.getCreditHours() + " hours");
        txtYear.setText(model.getLength() + " years");
        txtCost.setText("$" + model.getCost());
        txtDescription.setText(model.getDescription());
        txtSyllabus.setText(model.getSyllabus());
    }

    @OnClick(R.id.iv_back)
    public void onBackClick() {
        onBackPressed();
    }

    @OnClick(R.id.btn_submit)
    public void onSubmitClick() {
        CommonMethods.showProgress(this);
        interactor.submitCourseId(model.getId(), this);
    }

    @Override
    public void onFailure(Throwable throwable) {
        CommonMethods.hideProgress();
        ToastUtils.shortToast(throwable.getMessage());
    }

    @Override
    public void onSelectedCourseSuccess(CommonResponse response) {
        CommonMethods.hideProgress();
        if (response.getReturn() == 1){
            ToastUtils.shortToast(response.getMessage());
            finish();
        }
        else{

            ToastUtils.shortToast(response.getMessage());
        }

    }
}
