package com.app.college.UserInterface.main.students.registerPayForCourse.majors;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.app.college.R;
import com.app.college.UserInterface.main.students.registerPayForCourse.science.ScienceActivity;
import com.app.college.data.getMajors.Datum;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by 123 on 07-06-2018.
 */

public class MajorFragmentAdapter extends RecyclerView.Adapter<MajorFragmentAdapter.MyViewHolder>{

    Context context;
    List<Datum> majorCourses= new ArrayList<>();

    public MajorFragmentAdapter(Context context, List<Datum> majorCourses)
    {
        this.context= context;
        this.majorCourses= majorCourses;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_major_fragment,null);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, final int position) {
        holder.tvmajors.setText(majorCourses.get(position).getName());
        holder.rlMajors.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(context,ScienceActivity.class);
                intent.putExtra("courseId",majorCourses.get(position).getId());
                intent.putExtra("name",majorCourses.get(position).getName());
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return majorCourses.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView tvmajors;
        RelativeLayout rlMajors;
        public MyViewHolder(View itemView) {
            super(itemView);

            tvmajors= itemView.findViewById(R.id.tv_majors);
            rlMajors=itemView.findViewById(R.id.rl_majors);
        }
    }
}
