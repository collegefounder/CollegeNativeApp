package com.app.college.UserInterface.main.students.registerPayForCourse.majors;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.app.college.R;
import com.app.college.UserInterface.main.students.news.NewsActivity;
import com.app.college.data.getMajors.Datum;
import com.app.college.data.getMajors.GetMajors;
import com.app.college.ui.authenticate.interactor.GetMajorsInteractor;
import com.app.college.ui.authenticate.intractorImpl.GetMajorsInteractorImpl;
import com.app.college.utils.CommonMethods;
import com.app.college.utils.ToastUtils;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by 123 on 07-06-2018.
 */

public class MajorsFragment extends Fragment implements GetMajorsInteractor.OnCompleteListener{

    @BindView(R.id.rv_majors)
    public RecyclerView rvMajors;
    private List<Datum> majorCourses = new ArrayList<>();
    private GetMajorsInteractor getMajorsInteractor;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_major, container, false);
        ButterKnife.bind(this,view);
        getMajorsInteractor = new GetMajorsInteractorImpl(getActivity());

        return view;
    }

    private void initializeList() {
        majorCourses.clear();
        CommonMethods.showProgress(getActivity());
        getMajorsInteractor.getMajors(this);

    }

    @Override
    public void onResume() {
        super.onResume();
        initializeList();
    }

    //    @OnClick(R.id.btn_submit)
//    public void onSubmit() {
//        Intent intent = new Intent(getActivity(), NewsActivity.class);
//        startActivity(intent);
//    }

    @Override
    public void onSuccess(GetMajors response) {
        CommonMethods.hideProgress();
        if (response.getReturn() == 1){
            majorCourses.addAll(response.getData());
            rvMajors.setLayoutManager(new LinearLayoutManager(getContext()));
            MajorFragmentAdapter majorFragmentAdapter = new MajorFragmentAdapter(getActivity(), majorCourses);
            rvMajors.setAdapter(majorFragmentAdapter);
        }
        else{
            ToastUtils.shortToast(response.getMessage());
        }
    }

    @Override
    public void onFailure(Throwable throwable) {
        CommonMethods.hideProgress();
    }
}
