package com.app.college.UserInterface.main.students.registerPayForCourse.science;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import com.app.college.R;
import com.app.college.UserInterface.main.students.registerPayForCourse.allCourses.AllCoursesFragmentAdapter;
import com.app.college.data.getAllCourses.GetAllCourse;
import com.app.college.data.getAllCourses.GetAllCourseDataList;
import com.app.college.ui.authenticate.interactor.GetMajorCoursesInteractor;
import com.app.college.ui.authenticate.intractorImpl.GetMajorCoursesInteractorImpl;
import com.app.college.utils.CommonMethods;
import com.app.college.utils.ToastUtils;
import java.util.ArrayList;
import java.util.List;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by 123 on 06-06-2018.
 */

public class ScienceActivity extends AppCompatActivity implements GetMajorCoursesInteractor.OnCompleteListener{

    @BindView(R.id.rv_medical)
    public RecyclerView rvMedical;
    @BindView(R.id.iv_back)
    public ImageView ivBack;
    @BindView(R.id.tv_header)
    public TextView tvHeader;
    private GetMajorCoursesInteractor majorCoursesInteractor;
    private int majorId;
    private String name;

    private List<GetAllCourseDataList> courses= new ArrayList<>();
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_science);
        ButterKnife.bind(this);
        majorCoursesInteractor = new GetMajorCoursesInteractorImpl(this);
        ivBack.setVisibility(View.VISIBLE);
        majorId = getIntent().getIntExtra("courseId",0);
        name = getIntent().getStringExtra("name");
        tvHeader.setText(name);

    }

    private void initCourses() {
        courses.clear();
        CommonMethods.showProgress(this);
        majorCoursesInteractor.getMajorCourses(majorId,this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        initCourses();
    }

    //    @OnClick(R.id.btn_submit)
//    public void onSubmit()
//    {
//        Intent intent= new Intent(this,CoursesDetailsRegPayActivity.class);
//        startActivity(intent);
//    }


    @OnClick(R.id.iv_back)
    public void onBackClick()
    {
        onBackPressed();
    }

    @Override
    public void onSuccess(GetAllCourse response) {
        CommonMethods.hideProgress();
        if (response.getReturn() == 1){
            courses.addAll(response.getData().getData());
            rvMedical.setLayoutManager(new LinearLayoutManager(this));
            AllCoursesFragmentAdapter allCoursesFragmentAdapter= new AllCoursesFragmentAdapter(this,courses);
            rvMedical.setAdapter(allCoursesFragmentAdapter);
        }
        else{
            ToastUtils.shortToast(response.getMessage());
        }
    }

    @Override
    public void onFailure(Throwable throwable) {
        CommonMethods.hideProgress();
    }
}
