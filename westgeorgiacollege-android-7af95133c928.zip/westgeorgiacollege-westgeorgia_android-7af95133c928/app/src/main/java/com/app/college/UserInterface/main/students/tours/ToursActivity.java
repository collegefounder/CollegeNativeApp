package com.app.college.UserInterface.main.students.tours;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.app.college.R;
import com.app.college.UserInterface.main.students.tours.registration.RegistrationFragment;
import com.app.college.UserInterface.main.students.tours.demoVideos.DemoVideoFragment;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by 123 on 08-06-2018.
 */

public class ToursActivity extends AppCompatActivity {


    @BindView(R.id.rl_registration)
    public RelativeLayout rlRegistration;
    @BindView(R.id.rl_demo_video)
    public RelativeLayout rlDemoVideo;
    @BindView(R.id.iv_registration)
    public ImageView ivRegistration;
    @BindView(R.id.iv_demo_video)
    public ImageView ivDemoVideo;
    @BindView(R.id.tv_registration)
    public TextView tvRegistration;
    @BindView(R.id.tv_demo_video)
    public TextView tvDemoVideo;

    @BindView(R.id.tv_header)
    public TextView tvHeader;
    @BindView(R.id.iv_back)
    public ImageView ivBack;
    @BindView(R.id.frame_layout)
    public FrameLayout frameLayout;

    Fragment fragment= null;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tours);
        ButterKnife.bind(this);

        tvHeader.setText(getString(R.string.tours));
        ivBack.setVisibility(View.VISIBLE);
        switchFragments(new RegistrationFragment());
    }


    @OnClick(R.id.iv_back)
    public void onBackClick()
    {
        onBackPressed();
    }

    @OnClick(R.id.rl_registration)
    public void onRegistrationClick()
    {
        rlRegistration.setBackgroundResource(R.color.selected_list);
        tvRegistration.setTextColor(ContextCompat.getColor(this, R.color.white));
        ivRegistration.setVisibility(View.VISIBLE);
        rlDemoVideo.setBackgroundResource(R.drawable.rec_blue_border);
        tvDemoVideo.setTextColor(ContextCompat.getColor(this, R.color.selected_list));
        ivDemoVideo.setVisibility(View.GONE);

//        fragment=new RegistrationFragment();
        switchFragments(new RegistrationFragment());
    }

    @OnClick(R.id.rl_demo_video)
    public void onVideoClick()
    {
        rlDemoVideo.setBackgroundResource(R.color.selected_list);
        tvDemoVideo.setTextColor(ContextCompat.getColor(this, R.color.white));
        ivDemoVideo.setVisibility(View.VISIBLE);
        rlRegistration.setBackgroundResource(R.drawable.rec_blue_border);
        tvRegistration.setTextColor(ContextCompat.getColor(this, R.color.selected_list));
        ivRegistration.setVisibility(View.GONE);

       switchFragments(new DemoVideoFragment());
    }

    private void switchFragments(Fragment fragment){

        FragmentManager fragmentManager= getSupportFragmentManager();
        FragmentTransaction fragmentTransaction= fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.frame_layout,fragment);
        fragmentTransaction.commit();
    }
}