package com.app.college.UserInterface.main.students.tours.registration;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


import com.app.college.R;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * Created by 123 on 08-06-2018.
 */

public class RegistrationFragment extends Fragment {

    @BindView(R.id.et_name)
    public EditText etName;

    @BindView(R.id.et_phone_number)
    public EditText etPhoneNumber;

    @BindView(R.id.et_email_address)
    public EditText etEmailAddress;

    @BindView(R.id.et_address)
    public EditText etAddress;

    @BindView(R.id.btn_register)
    public Button btnRegister;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view= inflater.inflate(R.layout.fragment_registration,container,false);
        return view;
    }

    @OnClick(R.id.btn_register)
    public void onRegisterClick()
    {
        Toast.makeText(getActivity(),"Under Development",Toast.LENGTH_SHORT).show();
    }
}
