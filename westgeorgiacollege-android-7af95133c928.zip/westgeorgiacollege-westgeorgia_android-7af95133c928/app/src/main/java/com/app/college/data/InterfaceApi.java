package com.app.college.data;

import com.app.college.data.allcourses.GetAllCoursesResponse;
import com.app.college.data.businessSignup.BusinessSignup;
import com.app.college.data.checkSocialId.CheckSocialId;
import com.app.college.data.forgotPassword.ForgotPassword;
import com.app.college.data.getAllCourses.GetAllCourse;
import com.app.college.data.getInstitute.GetInstitute;
import com.app.college.data.getMajorCourses.GetMajorCourses;
import com.app.college.data.getMajors.GetMajors;
import com.app.college.data.login.LoginBean;
import com.app.college.data.socialLoginBusiness.BusinessSocialSignup;
import com.app.college.data.socialLoginStudent.SocialLoginStudent;
import com.app.college.data.studentSignUp.StudentSignup;

import org.json.JSONArray;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;

/**
 * Created by 123 on 12-Feb-18.
 */

public interface InterfaceApi {

    //    String BASE_URL = "http://14.141.82.38/webservices/sim/public/api/"; // local url
//    String BASE_URL = "http://54.206.13.240/sim_admin/public/api/";  // live url

//    String BASE_URL = "http://175.176.186.116/webservices/jonathan_dev/public/api/v1/";
//String BASE_URL = "http://1.6.98.139/webservices/jonathan_dev/public/api/v1/";
       String BASE_URL = "http://1.6.98.139/webservices/jonathan/public/api/v1/";
   // String BASE_URL = "http://175.176.186.116/webservices/jonathan/public/api/v1/";

    @FormUrlEncoded
    @POST("signup/student")
    Call<StudentSignup> signUpApi(@Field("first_name") String firstName, @Field("last_name") String lastName, @Field("address") String address, @Field("email") String email, @Field("phone_number") String phone_number, @Field("password") String password, @Field("device_type") String device_type, @Field("device_token") String device_token);

    @FormUrlEncoded
    @POST("signin")
    Call<LoginBean> login(@Field("email") String email, @Field("password") String password, @Field("device_type") String device_type, @Field("device_token") String device_token);

    @FormUrlEncoded
    @POST("forgot_password")
    Call<ForgotPassword> forgotPassword(@Field("email") String email);

    @FormUrlEncoded
    @POST("checkSocialId")
    Call<CheckSocialId> checkSocialId(@Field("social_id") String socialId, @Field("device_token") String deviceToken, @Field("device_type") String deviceType);

    @FormUrlEncoded
    @POST("signup/business")
    Call<BusinessSignup> businessSignup(@Field("business_name") String businesName, @Field("business_address") String businessAddress, @Field("manager_name") String managerName, @Field("phone_number") String phoneNumber, @Field("email") String email, @Field("phone_number_student") String phoneNumberStudent,
                                        @Field("email_student") String email_student, @Field("password") String password, @Field("nearby_colleges") JSONArray nearbyColleges, @Field("device_type") String deviceType, @Field("device_token") String deviceToken);

    @FormUrlEncoded
    @POST("social/business")
    Call<BusinessSocialSignup> businessSocialSignup(@Field("social_type") String social_type, @Field("social_id") String social_id, @Field("business_name") String businesName, @Field("business_address") String businessAddress, @Field("manager_name") String managerName, @Field("phone_number") String phoneNumber, @Field("email") String email, @Field("phone_number_student") String phoneNumberStudent,
                                              @Field("email_student") String email_student, @Field("password") String password, @Field("nearby_colleges") JSONArray nearbyColleges, @Field("device_type") String deviceType, @Field("device_token") String deviceToken);

    @FormUrlEncoded
    @POST("social/student")
    Call<SocialLoginStudent> socialStudent(@Field("social_id") String SocialId, @Field("first_name") String firstName, @Field("last_name") String lastName, @Field("address") String address, @Field("email") String email, @Field("phone_number") String phoneNumber, @Field("password") String password,
                                            @Field("device_type") String deviceType, @Field("device_token") String deviceToken ,@Field("social_type") String socialType);

    @GET("getInstitute")
    Call<GetInstitute> getInstitute();

    @GET("majors")
    Call<GetMajors> getMajors();

    @FormUrlEncoded
    @POST("chooseInstitute")
    Call<CommonResponse> selectIntitude(@Field("institute_id") int id);


    @FormUrlEncoded
    @POST("registerForCourse")
    Call<CommonResponse> submitCourse(@Field("course_id") int courseId);


//    @FormUrlEncoded
//    @POST("getMajorCourses")
//    Call<GetMajorCourses> getMajorCourses(@Field("major_id") int majorId);



//    @FormUrlEncoded
//    @POST("getMajorCourses")
//    Call<GetMajorCourses> getMajorCourses(@Field("major_id") int majorId);

    @FormUrlEncoded
    @POST("getMajorCourses")
    Call<GetAllCourse> getMajorCourses(@Field("major_id") int majorId);

    @FormUrlEncoded
    @POST("getAllCourse")
    Call<GetAllCourse> getAllCourse(@Field("page") int page);


    @GET("getAllCourse")
    Call<GetAllCoursesResponse> getAllCourses();



}
