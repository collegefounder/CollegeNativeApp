package com.app.college.data;

import android.content.Context;
import android.util.Log;

import com.app.college.utils.App;
import com.app.college.utils.Constants;
import com.app.college.utils.helpers.SharedPreferenceHelper;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * Created by 123 on 1/27/2017.
 */

public class TokenInjector {

    static Context mContext;

    private static Retrofit provideRetrofit(String baseUrl, Context context) {
        return new Retrofit.Builder()
                .baseUrl(baseUrl)
                .client(provideOkHttpClient(context))
                .addConverterFactory(GsonConverterFactory.create())
                .build();
    }

    private static OkHttpClient provideOkHttpClient(final Context context) {

        mContext = context;
        return new OkHttpClient.Builder()
                .addInterceptor(new Interceptor() {
                    @Override
                    public Response intercept(Chain chain) throws IOException {
                        Request original = chain.request();

                        Log.e("token","Bearer "+new SharedPreferenceHelper(context).getPref(Constants.AUTH_TOKEN));

                        Request request = original.newBuilder()
                                .header("Authorization","Bearer "+new SharedPreferenceHelper(context).getPref(Constants.AUTH_TOKEN))
                                .header("Accept","application/json")
                                .method(original.method(),original.body())
                                .build();
                        return chain.proceed(request);
                    }
                })
                .addInterceptor(new ForbiddenInterceptor())
                .connectTimeout(120,TimeUnit.SECONDS)
                .readTimeout(120,TimeUnit.SECONDS)
                .writeTimeout(120,TimeUnit.SECONDS)
                .build();
    }


    public static InterfaceApi provideApi(Context context) {
        return provideRetrofit(InterfaceApi.BASE_URL,context).create(InterfaceApi.class);
    }

    public static class ForbiddenInterceptor implements Interceptor {

        @Override
        public Response intercept(final Chain chain) throws IOException {
            Request request = chain.request();
            Response response = chain.proceed(request);
            if (response.code() == 401) {
                App.startLoginActivity(mContext,response.code());
            }
            return response;
        }
    }

}




