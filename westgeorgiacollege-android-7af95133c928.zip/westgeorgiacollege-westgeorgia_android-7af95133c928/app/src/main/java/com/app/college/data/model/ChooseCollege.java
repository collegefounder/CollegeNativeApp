package com.app.college.data.model;

/**
 * Created by 123 on 06-06-2018.
 */

public class ChooseCollege {

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    String name ;
    boolean checked = false;

    public boolean isChecked() {
        return checked;
    }

    public void setChecked(boolean checked) {
        this.checked = checked;
    }
}
