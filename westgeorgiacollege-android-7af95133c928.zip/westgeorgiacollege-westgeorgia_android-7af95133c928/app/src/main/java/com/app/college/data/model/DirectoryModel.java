package com.app.college.data.model;

/**
 * Created by 123 on 12-06-2018.
 */

public class DirectoryModel {
    String name;
    boolean selected;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isSelected() {
        return selected;
    }

    public void setSelected(boolean selected) {
        this.selected = selected;
    }
}
