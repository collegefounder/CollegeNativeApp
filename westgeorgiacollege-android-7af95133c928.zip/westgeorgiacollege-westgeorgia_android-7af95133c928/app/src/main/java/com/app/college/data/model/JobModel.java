package com.app.college.data.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class JobModel {

    String jobTitle;
    String jobLocation;
    String jobDescription;

    String name;
    String userName;
    String number;

    String from;
}
