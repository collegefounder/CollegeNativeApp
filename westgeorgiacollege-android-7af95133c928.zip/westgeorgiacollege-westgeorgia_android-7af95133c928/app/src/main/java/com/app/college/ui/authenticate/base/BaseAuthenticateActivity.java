package com.app.college.ui.authenticate.base;

import android.os.Bundle;
import android.support.annotation.Nullable;

import com.app.college.ui.base.BaseActivity;


/**
 * Created by 123 on 04-Jan-18.
 */

public abstract class BaseAuthenticateActivity extends BaseActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}
