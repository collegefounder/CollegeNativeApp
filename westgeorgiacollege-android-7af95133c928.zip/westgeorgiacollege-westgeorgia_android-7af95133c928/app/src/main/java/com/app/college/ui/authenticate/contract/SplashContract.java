package com.app.college.ui.authenticate.contract;


import com.app.college.ui.base.BasePresentor;
import com.app.college.ui.base.BaseView;

/**
 * Created by 123 on 04-Jan-18.
 */

public interface SplashContract {

    interface View extends BaseView {

        void next();
    }

    interface Presentor extends BasePresentor<View> {

        void callNext();
    }

    interface Intractor {

        void waitForNext(OnCompleteListener callback);
    }

    interface OnCompleteListener {

        void onSuccess();
    }
}
