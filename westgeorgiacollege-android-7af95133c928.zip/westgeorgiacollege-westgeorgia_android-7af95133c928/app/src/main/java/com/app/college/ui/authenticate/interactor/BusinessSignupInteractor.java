package com.app.college.ui.authenticate.interactor;

import com.app.college.data.businessSignup.BusinessSignup;
import com.app.college.data.studentSignUp.StudentSignup;

import org.json.JSONArray;

import java.util.ArrayList;

/**
 * Created by ubuntu on 19/7/18.
 */

public interface BusinessSignupInteractor {

    interface OnCompleteListener{
        void onSuccess(BusinessSignup response);
        void onFailure(Throwable throwable);
    }

    void businessSignup(String business_name, String business_address, String manager_name, String phone_number, String email, String phone_number_student, String email_student, String password, JSONArray nearbyColleges, String device_type, String device_token, OnCompleteListener onCompleteListener);

}
