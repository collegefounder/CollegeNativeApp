package com.app.college.ui.authenticate.interactor;

import com.app.college.data.checkSocialId.CheckSocialId;
import com.app.college.data.forgotPassword.ForgotPassword;

/**
 * Created by ubuntu on 19/7/18.
 */

public interface CheckLoginInteractor {

    interface OnCompleteListener{
        void onSuccess(CheckSocialId response);
        void onFailure(Throwable throwable);
    }

    void checkLogin(String social_id, String device_token, String device_type, OnCompleteListener onCompleteListener);

}
