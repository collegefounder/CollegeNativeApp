package com.app.college.ui.authenticate.interactor;

import com.app.college.data.forgotPassword.ForgotPassword;
import com.app.college.data.login.LoginBean;

/**
 * Created by ubuntu on 19/7/18.
 */

public interface ForgotInteractor {

    interface OnCompleteListener{
        void onSuccess(ForgotPassword response);
        void onFailure(Throwable throwable);
    }

    void forgot(String email, OnCompleteListener onCompleteListener);

}
