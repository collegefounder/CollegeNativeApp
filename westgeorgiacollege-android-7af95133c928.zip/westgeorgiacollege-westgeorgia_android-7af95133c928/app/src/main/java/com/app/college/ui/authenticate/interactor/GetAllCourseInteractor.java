package com.app.college.ui.authenticate.interactor;

import com.app.college.data.allcourses.GetAllCoursesResponse;


public interface GetAllCourseInteractor {


    interface OnCompleteListener{
        void onAllCourseSuccess(GetAllCoursesResponse response);
        void onFailure(Throwable throwable);
    }

    void getAllCourse(OnCompleteListener onCompleteListener);

}
