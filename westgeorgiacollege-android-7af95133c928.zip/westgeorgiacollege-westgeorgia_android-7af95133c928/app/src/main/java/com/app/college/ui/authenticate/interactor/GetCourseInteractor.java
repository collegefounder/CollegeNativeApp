package com.app.college.ui.authenticate.interactor;

import com.app.college.data.getAllCourses.GetAllCourse;


public interface GetCourseInteractor {


    interface OnCompleteListener{
        void onCourseSuccess(GetAllCourse response);
        void onFailure(Throwable throwable);
    }

    void getCourse(int page, OnCompleteListener onCompleteListener);
}
