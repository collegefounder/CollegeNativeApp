package com.app.college.ui.authenticate.interactor;

import com.app.college.data.CommonResponse;
import com.app.college.data.getInstitute.GetInstitute;
import com.app.college.data.login.LoginBean;

/**
 * Created by ubuntu on 19/7/18.
 */

public interface GetInstituteInteractor {

    void selectInstidte(int id,OnCompleteListener onCompleteListener);

    interface OnCompleteListener{
        void onSuccess(GetInstitute response);
        void onFailure(Throwable throwable);
        void onSelectInstitude(CommonResponse response);
    }

    void getInstitute(OnCompleteListener onCompleteListener);

}
