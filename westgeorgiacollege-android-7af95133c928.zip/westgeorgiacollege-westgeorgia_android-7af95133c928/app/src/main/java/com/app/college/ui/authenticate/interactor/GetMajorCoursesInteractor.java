package com.app.college.ui.authenticate.interactor;

import com.app.college.data.CommonResponse;
import com.app.college.data.getAllCourses.GetAllCourse;
import com.app.college.data.getInstitute.GetInstitute;
import com.app.college.data.getMajorCourses.GetMajorCourses;

/**
 * Created by ubuntu on 19/7/18.
 */

public interface GetMajorCoursesInteractor {

    interface OnCompleteListener{
        void onSuccess(GetAllCourse response);
        void onFailure(Throwable throwable);
    }

    void getMajorCourses(int majorId, OnCompleteListener onCompleteListener);

}
