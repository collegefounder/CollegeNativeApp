package com.app.college.ui.authenticate.interactor;

import com.app.college.data.getInstitute.GetInstitute;
import com.app.college.data.getMajors.GetMajors;

/**
 * Created by ubuntu on 19/7/18.
 */

public interface GetMajorsInteractor {

    interface OnCompleteListener{
        void onSuccess(GetMajors response);
        void onFailure(Throwable throwable);
    }

    void getMajors(OnCompleteListener onCompleteListener);

}
