package com.app.college.ui.authenticate.interactor;

import com.app.college.data.login.LoginBean;

/**
 * Created by ubuntu on 19/7/18.
 */

public interface LoginInteractor {

    interface OnCompleteListener{
        void onSuccess(LoginBean response);
        void onFailure(Throwable throwable);
    }

    void login(String email, String password, String deviceType, String deviceToken, OnCompleteListener onCompleteListener);

}
