package com.app.college.ui.authenticate.interactor;

import com.app.college.data.businessSignup.BusinessSignup;
import com.app.college.data.socialLoginBusiness.BusinessSocialSignup;

import org.json.JSONArray;

/**
 * Created by ubuntu on 19/7/18.
 */

public interface SocialBusinessSignupInteractor {

    interface OnCompleteListener{
        void onSuccess(BusinessSocialSignup response);
        void onFailure(Throwable throwable);
    }

    void businessSocial(String social_type,String social_id, String business_name, String business_address, String manager_name, String phone_number, String email, String phone_number_student, String email_student, String password, JSONArray nearbyColleges, String device_type, String device_token, OnCompleteListener onCompleteListener);

}
