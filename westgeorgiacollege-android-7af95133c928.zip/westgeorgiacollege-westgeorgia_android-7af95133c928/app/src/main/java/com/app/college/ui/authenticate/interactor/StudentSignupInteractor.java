package com.app.college.ui.authenticate.interactor;

import com.app.college.data.studentSignUp.StudentSignup;

/**
 * Created by ubuntu on 19/7/18.
 */

public interface StudentSignupInteractor {

    interface OnCompleteListener{
        void onSuccess(StudentSignup response);
        void onFailure(Throwable throwable);
    }

    void studentSignup(String firstName, String lastName, String address, String email, String phoneNumber, String password, String deviceType, String deviceToken,OnCompleteListener onCompleteListener);

}
