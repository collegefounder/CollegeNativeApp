package com.app.college.ui.authenticate.interactor;

import com.app.college.UserInterface.main.students.registerPayForCourse.courseDetails.CoursesDetailsRegPayActivity;
import com.app.college.data.CommonResponse;
import com.app.college.data.getInstitute.GetInstitute;

public interface SubmitCourseInteractor {


    void submitCourseId(int courseId, OnCompleteListener callBack);


    interface OnCompleteListener{
        void onFailure(Throwable throwable);
        void onSelectedCourseSuccess(CommonResponse response);
    }
}
