package com.app.college.ui.authenticate.intractorImpl;

import com.app.college.data.Injector;
import com.app.college.data.InterfaceApi;
import com.app.college.data.businessSignup.BusinessSignup;
import com.app.college.data.socialLoginBusiness.BusinessSocialSignup;
import com.app.college.ui.authenticate.interactor.BusinessSignupInteractor;
import com.app.college.ui.authenticate.interactor.SocialBusinessSignupInteractor;
import com.app.college.utils.App;

import org.json.JSONArray;
import org.json.JSONObject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


/**
 * Created by ubuntu on 19/7/18.
 */

public class BusinessSocialSignUpInteractorImpl implements SocialBusinessSignupInteractor {

    private static final String NO_INTERNET_CONNECTION = "No Internet Connection";
    private InterfaceApi api;

    public BusinessSocialSignUpInteractorImpl(){
        api= Injector.provideApi();
    }


    @Override
    public void businessSocial(String social_type, String social_id, String business_name, String business_address, String manager_name, String phone_number, String email, String phone_number_student, String email_student, String password, JSONArray nearbyColleges, String device_type, String device_token, final OnCompleteListener onCompleteListener) {
        if(!App.hasNetwork()){
            onCompleteListener.onFailure(new Throwable(NO_INTERNET_CONNECTION));
            return;
        }
        api.businessSocialSignup(social_type,social_id,business_name,business_address,manager_name,phone_number,email,phone_number_student,email_student,password,nearbyColleges,device_type,device_token).enqueue(new Callback<BusinessSocialSignup>() {
            @Override
            public void onResponse(Call<BusinessSocialSignup> call, Response<BusinessSocialSignup> response) {
                if(response.isSuccessful()){
                    onCompleteListener.onSuccess(response.body());
                }
                else{
                    try{
                        String errorBody=response.errorBody().string();
                        JSONObject object=new JSONObject(errorBody);
                        String errorMessage=object.getString("message");
                        onCompleteListener.onFailure(new Throwable(errorMessage));

                    }
                    catch (Exception e){
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(Call<BusinessSocialSignup> call, Throwable t) {
                onCompleteListener.onFailure(new Throwable(t.getMessage()));
            }
        });
    }
}
