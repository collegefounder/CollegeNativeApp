package com.app.college.ui.authenticate.intractorImpl;

import com.app.college.data.Injector;
import com.app.college.data.InterfaceApi;
import com.app.college.data.checkSocialId.CheckSocialId;
import com.app.college.data.forgotPassword.ForgotPassword;
import com.app.college.ui.authenticate.interactor.CheckLoginInteractor;
import com.app.college.ui.authenticate.interactor.ForgotInteractor;
import com.app.college.utils.App;

import org.json.JSONObject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


/**
 * Created by ubuntu on 19/7/18.
 */

public class CheckLoginInteractorImpl implements CheckLoginInteractor{

    private static final String NO_INTERNET_CONNECTION = "No Internet Connection";
    private InterfaceApi api;

    public CheckLoginInteractorImpl(){
        api= Injector.provideApi();
    }


    @Override
    public void checkLogin(String socialId, String deviceToken, String deviceType, final OnCompleteListener onCompleteListener) {
        if(!App.hasNetwork()){
            onCompleteListener.onFailure(new Throwable(NO_INTERNET_CONNECTION));
            return;
        }
        api.checkSocialId(socialId,deviceToken,deviceType).enqueue(new Callback<CheckSocialId>() {
            @Override
            public void onResponse(Call<CheckSocialId> call, Response<CheckSocialId> response) {
                if(response.isSuccessful()){
                    onCompleteListener.onSuccess(response.body());
                }
                else{
                    try{
                        String errorBody=response.errorBody().string();
                        JSONObject object=new JSONObject(errorBody);
                        String errorMessage=object.getString("message");
                        onCompleteListener.onFailure(new Throwable(errorMessage));

                    }
                    catch (Exception e){
                        e.printStackTrace();
//                        onCompleteListener.onFailure(new Throwable("Login Server Error"));
                    }
                }
            }

            @Override
            public void onFailure(Call<CheckSocialId> call, Throwable t) {
                onCompleteListener.onFailure(new Throwable(t.getMessage()));
            }
        });
    }
}
