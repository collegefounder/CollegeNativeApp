package com.app.college.ui.authenticate.intractorImpl;

import com.app.college.data.Injector;
import com.app.college.data.InterfaceApi;
import com.app.college.data.forgotPassword.ForgotPassword;
import com.app.college.data.login.LoginBean;
import com.app.college.ui.authenticate.interactor.ForgotInteractor;
import com.app.college.ui.authenticate.interactor.LoginInteractor;
import com.app.college.utils.App;

import org.json.JSONObject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


/**
 * Created by ubuntu on 19/7/18.
 */

public class ForgotInteractorImpl implements ForgotInteractor{

    private static final String NO_INTERNET_CONNECTION = "No Internet Connection";
    private InterfaceApi api;

    public ForgotInteractorImpl(){
        api= Injector.provideApi();
    }


    @Override
    public void forgot(String email,final OnCompleteListener onCompleteListener) {
        if(!App.hasNetwork()){
            onCompleteListener.onFailure(new Throwable(NO_INTERNET_CONNECTION));
            return;
        }
        api.forgotPassword(email).enqueue(new Callback<ForgotPassword>() {
            @Override
            public void onResponse(Call<ForgotPassword> call, Response<ForgotPassword> response) {
                if(response.isSuccessful()){
                    onCompleteListener.onSuccess(response.body());
                }
                else{
                    try{
                        String errorBody=response.errorBody().string();
                        JSONObject object=new JSONObject(errorBody);
                        String errorMessage=object.getString("message");
                        onCompleteListener.onFailure(new Throwable(errorMessage));

                    }
                    catch (Exception e){
                        e.printStackTrace();
//                        onCompleteListener.onFailure(new Throwable("Login Server Error"));
                    }
                }
            }

            @Override
            public void onFailure(Call<ForgotPassword> call, Throwable t) {
                onCompleteListener.onFailure(new Throwable(t.getMessage()));
            }
        });
    }
}
