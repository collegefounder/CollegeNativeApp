package com.app.college.ui.authenticate.intractorImpl;

import android.content.Context;
import com.app.college.data.InterfaceApi;
import com.app.college.data.TokenInjector;
import com.app.college.data.allcourses.GetAllCoursesResponse;
import com.app.college.ui.authenticate.interactor.GetAllCourseInteractor;
import com.app.college.utils.App;
import com.app.college.utils.Constants;
import org.json.JSONObject;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class GetAllCourseInteractorImpl implements GetAllCourseInteractor {

    InterfaceApi api;
    public GetAllCourseInteractorImpl(Context mContext) {
        api= TokenInjector.provideApi(mContext);
    }

    @Override
    public void getAllCourse(final OnCompleteListener onCompleteListener) {

        if(!App.hasNetwork()){
            onCompleteListener.onFailure(new Throwable(Constants.NO_INTERNET_CONNECTION));
            return;
        }
        api.getAllCourses().enqueue(new Callback<GetAllCoursesResponse>() {
            @Override
            public void onResponse(Call<GetAllCoursesResponse> call, Response<GetAllCoursesResponse> response) {
                if(response.isSuccessful()){
                    onCompleteListener.onAllCourseSuccess(response.body());
                }
                else{
                    try{
                        String errorBody=response.errorBody().string();
                        JSONObject object=new JSONObject(errorBody);
                        String errorMessage=object.getString("message");
                        onCompleteListener.onFailure(new Throwable(errorMessage));

                    }
                    catch (Exception e){
                        e.printStackTrace();
//                        onCompleteListener.onFailure(new Throwable("Login Server Error"));
                    }
                }
            }

            @Override
            public void onFailure(Call<GetAllCoursesResponse> call, Throwable t) {
                onCompleteListener.onFailure(new Throwable(t.getMessage()));
            }
        });
    }


    }

