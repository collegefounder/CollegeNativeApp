package com.app.college.ui.authenticate.intractorImpl;

import android.content.Context;

import com.app.college.data.InterfaceApi;
import com.app.college.data.TokenInjector;
import com.app.college.data.getAllCourses.GetAllCourse;
import com.app.college.ui.authenticate.interactor.GetCourseInteractor;
import com.app.college.utils.App;
import com.app.college.utils.Constants;

import org.json.JSONObject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class GetCourseInteractorImpl implements GetCourseInteractor {

    InterfaceApi api;
    public GetCourseInteractorImpl(Context mContext) {
        api= TokenInjector.provideApi(mContext);
    }

    @Override
    public void getCourse(int page, final OnCompleteListener onCompleteListener) {

        if(!App.hasNetwork()){
            onCompleteListener.onFailure(new Throwable(Constants.NO_INTERNET_CONNECTION));
            return;
        }
        api.getAllCourse(page).enqueue(new Callback<GetAllCourse>() {
            @Override
            public void onResponse(Call<GetAllCourse> call, Response<GetAllCourse> response) {
                if(response.isSuccessful()){
                    onCompleteListener.onCourseSuccess(response.body());
                }
                else{
                    try{
                        String errorBody=response.errorBody().string();
                        JSONObject object=new JSONObject(errorBody);
                        String errorMessage=object.getString("message");
                        onCompleteListener.onFailure(new Throwable(errorMessage));

                    }
                    catch (Exception e){
                        e.printStackTrace();
//                        onCompleteListener.onFailure(new Throwable("Login Server Error"));
                    }
                }
            }

            @Override
            public void onFailure(Call<GetAllCourse> call, Throwable t) {
                onCompleteListener.onFailure(new Throwable(t.getMessage()));
            }
        });
    }


    }

