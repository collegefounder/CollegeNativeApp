package com.app.college.ui.authenticate.intractorImpl;

import com.app.college.data.CommonResponse;
import com.app.college.data.Injector;
import com.app.college.data.InterfaceApi;
import com.app.college.data.getInstitute.GetInstitute;
import com.app.college.data.login.LoginBean;
import com.app.college.ui.authenticate.interactor.GetInstituteInteractor;
import com.app.college.ui.authenticate.interactor.LoginInteractor;
import com.app.college.utils.App;

import org.json.JSONObject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


/**
 * Created by ubuntu on 19/7/18.
 */

public class GetInstituteInteractorImpl implements GetInstituteInteractor{

    private static final String NO_INTERNET_CONNECTION = "No Internet Connection";
    private InterfaceApi api;

    public GetInstituteInteractorImpl(){
        api= Injector.provideApi();
    }


    @Override
    public void selectInstidte(int id,final OnCompleteListener onCompleteListener) {
        if(!App.hasNetwork()){
            onCompleteListener.onFailure(new Throwable(NO_INTERNET_CONNECTION));
            return;
        }
        api.selectIntitude(id).enqueue(new Callback<CommonResponse>() {
            @Override
            public void onResponse(Call<CommonResponse> call, Response<CommonResponse> response) {
                if(response.isSuccessful()){
                    onCompleteListener.onSelectInstitude(response.body());
                }
                else{
                    try{
                        String errorBody=response.errorBody().string();
                        JSONObject object=new JSONObject(errorBody);
                        String errorMessage=object.getString("message");
                        onCompleteListener.onFailure(new Throwable(errorMessage));

                    }
                    catch (Exception e){
                        e.printStackTrace();
 //onCompleteListener.onFailure(new Throwable("Server Error"));
                    }
                }
            }

            @Override
            public void onFailure(Call<CommonResponse> call, Throwable t) {

            }
        });


    }

    @Override
    public void getInstitute(final OnCompleteListener onCompleteListener) {
        if(!App.hasNetwork()){
            onCompleteListener.onFailure(new Throwable(NO_INTERNET_CONNECTION));
            return;
        }
        api.getInstitute().enqueue(new Callback<GetInstitute>() {
            @Override
            public void onResponse(Call<GetInstitute> call, Response<GetInstitute> response) {
                if(response.isSuccessful()){
                    onCompleteListener.onSuccess(response.body());
                }
                else{
                    try{
                        String errorBody=response.errorBody().string();
                        JSONObject object=new JSONObject(errorBody);
                        String errorMessage=object.getString("message");
                        onCompleteListener.onFailure(new Throwable(errorMessage));

                    }
                    catch (Exception e){
                        e.printStackTrace();
//                        onCompleteListener.onFailure(new Throwable("Login Server Error"));
                    }
                }
            }

            @Override
            public void onFailure(Call<GetInstitute> call, Throwable t) {
                onCompleteListener.onFailure(new Throwable(t.getMessage()));
            }
        });
    }
}
