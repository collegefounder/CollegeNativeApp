package com.app.college.ui.authenticate.intractorImpl;

import android.content.Context;

import com.app.college.data.InterfaceApi;
import com.app.college.data.TokenInjector;
import com.app.college.data.getAllCourses.GetAllCourse;
import com.app.college.ui.authenticate.interactor.GetMajorCoursesInteractor;
import com.app.college.utils.App;
import org.json.JSONObject;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


/**
 * Created by ubuntu on 19/7/18.
 */

public class GetMajorCoursesInteractorImpl implements GetMajorCoursesInteractor{

    private static final String NO_INTERNET_CONNECTION = "No Internet Connection";
    private InterfaceApi api;

    public GetMajorCoursesInteractorImpl(Context context){
        api= TokenInjector.provideApi(context);
    }


    @Override
    public void getMajorCourses(int majorId,final OnCompleteListener onCompleteListener) {
        if(!App.hasNetwork()){
            onCompleteListener.onFailure(new Throwable(NO_INTERNET_CONNECTION));
            return;
        }
        api.getMajorCourses(majorId).enqueue(new Callback<GetAllCourse>() {
            @Override
            public void onResponse(Call<GetAllCourse> call, Response<GetAllCourse> response) {
                if(response.isSuccessful()){
                    onCompleteListener.onSuccess(response.body());
                }
                else{
                    try{
                        String errorBody=response.errorBody().string();
                        JSONObject object=new JSONObject(errorBody);
                        String errorMessage=object.getString("message");
                        onCompleteListener.onFailure(new Throwable(errorMessage));

                    }
                    catch (Exception e){
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(Call<GetAllCourse> call, Throwable t) {
                onCompleteListener.onFailure(new Throwable(t.getMessage()));
            }
        });


    }
}
