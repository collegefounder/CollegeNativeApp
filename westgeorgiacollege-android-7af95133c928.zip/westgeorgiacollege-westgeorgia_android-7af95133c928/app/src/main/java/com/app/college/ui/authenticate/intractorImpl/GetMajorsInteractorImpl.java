package com.app.college.ui.authenticate.intractorImpl;

import android.content.Context;

import com.app.college.data.Injector;
import com.app.college.data.InterfaceApi;
import com.app.college.data.TokenInjector;
import com.app.college.data.getInstitute.GetInstitute;
import com.app.college.data.getMajors.GetMajors;
import com.app.college.ui.authenticate.interactor.GetInstituteInteractor;
import com.app.college.ui.authenticate.interactor.GetMajorsInteractor;
import com.app.college.utils.App;

import org.json.JSONObject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


/**
 * Created by ubuntu on 19/7/18.
 */

public class GetMajorsInteractorImpl implements GetMajorsInteractor {

    private static final String NO_INTERNET_CONNECTION = "No Internet Connection";
    private InterfaceApi api;

    public GetMajorsInteractorImpl(Context context){
        api= TokenInjector.provideApi(context);
    }


    @Override
    public void getMajors(final OnCompleteListener onCompleteListener) {
        if(!App.hasNetwork()){
            onCompleteListener.onFailure(new Throwable(NO_INTERNET_CONNECTION));
            return;
        }
        api.getMajors().enqueue(new Callback<GetMajors>() {
            @Override
            public void onResponse(Call<GetMajors> call, Response<GetMajors> response) {
                if(response.isSuccessful()){
                    onCompleteListener.onSuccess(response.body());
                }
                else{
                    try{
                        String errorBody=response.errorBody().string();
                        JSONObject object=new JSONObject(errorBody);
                        String errorMessage=object.getString("message");
                        onCompleteListener.onFailure(new Throwable(errorMessage));

                    }
                    catch (Exception e){
                        e.printStackTrace();
//                        onCompleteListener.onFailure(new Throwable("Login Server Error"));
                    }
                }
            }

            @Override
            public void onFailure(Call<GetMajors> call, Throwable t) {
                onCompleteListener.onFailure(new Throwable(t.getMessage()));
            }
        });
    }
}
