package com.app.college.ui.authenticate.intractorImpl;

import com.app.college.data.Injector;
import com.app.college.data.InterfaceApi;
import com.app.college.data.socialLoginStudent.SocialLoginStudent;
import com.app.college.data.studentSignUp.StudentSignup;
import com.app.college.ui.authenticate.interactor.SocialStudentInteractor;
import com.app.college.ui.authenticate.interactor.StudentSignupInteractor;
import com.app.college.utils.App;

import org.json.JSONObject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


/**
 * Created by ubuntu on 19/7/18.
 */

public class SocialStudentInteractorImpl implements SocialStudentInteractor{

    private static final String NO_INTERNET_CONNECTION = "No Internet Connection";
    private InterfaceApi api;

    public SocialStudentInteractorImpl(){
        api= Injector.provideApi();
    }


    @Override
    public void socialStudent(String socialId,String firstName, String lastName, String address, String email, String phoneNumber, String password, String deviceType, String deviceToken, String socialType,final OnCompleteListener onCompleteListener) {
        if(!App.hasNetwork()){
            onCompleteListener.onFailure(new Throwable(NO_INTERNET_CONNECTION));
            return;
        }
        api.socialStudent(socialId,firstName,lastName,address,email,phoneNumber,password,deviceType,deviceToken,socialType).enqueue(new Callback<SocialLoginStudent>() {
            @Override
            public void onResponse(Call<SocialLoginStudent> call, Response<SocialLoginStudent> response) {
                if(response.isSuccessful()){
                    onCompleteListener.onSuccess(response.body());
                }
                else{
                    try{
                        String errorBody=response.errorBody().string();
                        JSONObject object=new JSONObject(errorBody);
                        String errorMessage=object.getString("message");
                        onCompleteListener.onFailure(new Throwable(errorMessage));

                    }
                    catch (Exception e){
                        e.printStackTrace();
//                        onCompleteListener.onFailure(new Throwable("Login Server Error"));
                    }
                }
            }

            @Override
            public void onFailure(Call<SocialLoginStudent> call, Throwable t) {
                onCompleteListener.onFailure(new Throwable(t.getMessage()));
            }
        });
    }
}
