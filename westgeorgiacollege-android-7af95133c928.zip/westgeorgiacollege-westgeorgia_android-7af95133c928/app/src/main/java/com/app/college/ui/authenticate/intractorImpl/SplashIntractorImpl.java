package com.app.college.ui.authenticate.intractorImpl;

import android.os.Handler;

import com.app.college.ui.authenticate.contract.SplashContract;


/**
 * Created by 123 on 04-Jan-18.
 */

public class SplashIntractorImpl implements SplashContract.Intractor {

    @Override
    public void waitForNext(final SplashContract.OnCompleteListener callback) {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                callback.onSuccess();
            }
        }, 2000);
    }
}
