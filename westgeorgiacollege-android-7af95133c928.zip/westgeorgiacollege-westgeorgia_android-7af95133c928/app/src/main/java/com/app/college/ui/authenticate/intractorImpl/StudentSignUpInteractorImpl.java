package com.app.college.ui.authenticate.intractorImpl;

import com.app.college.data.Injector;
import com.app.college.data.InterfaceApi;
import com.app.college.data.studentSignUp.StudentSignup;
import com.app.college.ui.authenticate.interactor.StudentSignupInteractor;
import com.app.college.utils.App;
import com.app.college.utils.ToastUtils;

import org.json.JSONObject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


/**
 * Created by ubuntu on 19/7/18.
 */

public class StudentSignUpInteractorImpl implements StudentSignupInteractor{

    private static final String NO_INTERNET_CONNECTION = "No Internet Connection";
    private InterfaceApi api;

    public StudentSignUpInteractorImpl(){
        api= Injector.provideApi();
    }


    @Override
    public void studentSignup(String firstName, String lastName, String address, String email, String phoneNumber, String password, String deviceType, String deviceToken,final OnCompleteListener onCompleteListener) {
        if(!App.hasNetwork()){
            onCompleteListener.onFailure(new Throwable(NO_INTERNET_CONNECTION));
            return;
        }
        api.signUpApi(firstName,lastName,address,email,phoneNumber,password,deviceType,deviceToken).enqueue(new Callback<StudentSignup>() {
            @Override
            public void onResponse(Call<StudentSignup> call, Response<StudentSignup> response) {
                if(response.isSuccessful()){
                    onCompleteListener.onSuccess(response.body());
                }
                else{
                    try{
                        String errorBody=response.errorBody().string();
                        JSONObject object=new JSONObject(errorBody);
                        String errorMessage=object.getString("message");
                        onCompleteListener.onFailure(new Throwable(errorMessage));

                    }
                    catch (Exception e){
                        e.printStackTrace();
//                        onCompleteListener.onFailure(new Throwable("Login Server Error"));
                    }
                }
            }

            @Override
            public void onFailure(Call<StudentSignup> call, Throwable t) {
                onCompleteListener.onFailure(new Throwable(t.getMessage()));
            }
        });
    }
}
