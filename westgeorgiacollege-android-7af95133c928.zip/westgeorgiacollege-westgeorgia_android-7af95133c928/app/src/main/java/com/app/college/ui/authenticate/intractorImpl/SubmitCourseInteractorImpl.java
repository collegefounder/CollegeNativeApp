package com.app.college.ui.authenticate.intractorImpl;



import android.content.Context;

import com.app.college.UserInterface.main.students.registerPayForCourse.courseDetails.CoursesDetailsRegPayActivity;
import com.app.college.data.CommonResponse;
import com.app.college.data.InterfaceApi;
import com.app.college.data.TokenInjector;
import com.app.college.ui.authenticate.interactor.SubmitCourseInteractor;
import com.app.college.utils.App;
import com.app.college.utils.Constants;

import org.json.JSONObject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SubmitCourseInteractorImpl implements SubmitCourseInteractor {


    InterfaceApi api;
    public SubmitCourseInteractorImpl(Context mContext) {
       api=TokenInjector.provideApi(mContext);
    }

    @Override
    public void submitCourseId(int courseId, final OnCompleteListener callBack) {

        if(!App.hasNetwork()){
            callBack.onFailure(new Throwable(Constants.NO_INTERNET_CONNECTION));
            return;
        }

        api.submitCourse(courseId).enqueue(new Callback<CommonResponse>() {
            @Override
            public void onResponse(Call<CommonResponse> call, Response<CommonResponse> response) {
                if(response.isSuccessful()){
                    callBack.onSelectedCourseSuccess(response.body());
                }
                else{
                    try{
                        String errorBody=response.errorBody().string();
                        JSONObject object=new JSONObject(errorBody);
                        String errorMessage=object.getString("message");
                        callBack.onFailure(new Throwable(errorMessage));

                    }
                    catch (Exception e){
                        e.printStackTrace();
                        //onCompleteListener.onFailure(new Throwable("Server Error"));
                    }
                }
            }

            @Override
            public void onFailure(Call<CommonResponse> call, Throwable t) {
                callBack.onFailure(new Throwable(t.getMessage()));
            }
        });

    }
}
