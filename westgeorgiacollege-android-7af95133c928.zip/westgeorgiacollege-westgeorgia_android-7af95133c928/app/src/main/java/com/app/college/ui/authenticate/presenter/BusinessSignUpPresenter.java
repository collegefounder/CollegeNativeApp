package com.app.college.ui.authenticate.presenter;

import android.widget.EditText;

import org.json.JSONArray;

/**
 * Created by ubuntu on 19/7/18.
 */

public interface BusinessSignUpPresenter {

    void validateCredentials(EditText business_name, EditText business_address, EditText manager_name, EditText phone_number, EditText email, EditText phone_number_student, EditText email_student, EditText password, EditText confirm_password, String from);
    void businessSignup(String business_name, String business_address, String manager_name, String phone_number, String email, String phone_number_student, String email_student, String password, JSONArray nearbyColleges, String device_type, String device_token);
}
