package com.app.college.ui.authenticate.presenter;

import android.widget.EditText;

/**
 * Created by ubuntu on 19/7/18.
 */

public interface LoginPresenter {

    void validateCredentials(EditText email, EditText password);
    void login(String email, String password, String deviceType, String deviceToken);
}
