package com.app.college.ui.authenticate.presenter;

import android.widget.EditText;

/**
 * Created by ubuntu on 19/7/18.
 */

public interface StudentSignUpPresenter {

    void validateCredentials(EditText firstName, EditText lastName, EditText address, EditText email, EditText phoneNumber, EditText password, EditText confirmPassword, String from);
    void studentSignup(String firstName, String lastName, String address, String email, String phoneNumber, String password, String deviceType, String deviceToken);
}
