package com.app.college.ui.authenticate.presentorImpl;

import android.content.Context;
import android.widget.EditText;

import com.app.college.R;
import com.app.college.data.businessSignup.BusinessSignup;
import com.app.college.ui.authenticate.interactor.BusinessSignupInteractor;
import com.app.college.ui.authenticate.intractorImpl.BusinessSignUpInteractorImpl;
import com.app.college.ui.authenticate.presenter.BusinessSignUpPresenter;
import com.app.college.ui.authenticate.view.BusinessSignUpView;
import com.app.college.utils.ToastUtils;

import org.json.JSONArray;

/**
 * Created by ubuntu on 19/7/18.
 */

public class BusinessSignUpPresenterImpl implements BusinessSignUpPresenter, BusinessSignupInteractor.OnCompleteListener {


    BusinessSignUpView signupView;
    Context context;
    BusinessSignupInteractor interactor;

    public BusinessSignUpPresenterImpl(BusinessSignUpView signupView, Context context) {
        this.signupView = signupView;
        this.context = context;
        interactor = new BusinessSignUpInteractorImpl();
    }

    @Override
    public void validateCredentials(EditText business_name, EditText business_address, EditText manager_name, EditText phone_number, EditText email, EditText phone_number_student, EditText email_student, EditText password, EditText confirm_password, String from) {
        String businessName=business_name.getText().toString().trim();
        String businessAddress=business_address.getText().toString().trim();
        String managerName = manager_name.getText().toString().trim();
        String phoneNumber = phone_number.getText().toString().trim();
        String emailAddress = email.getText().toString().trim();
        String phoneNumberStudent = phone_number_student.getText().toString().trim();
        String emailStudent = email_student.getText().toString().trim();
        String txt_password = password.getText().toString().trim();
        String confirmPassword = confirm_password.getText().toString().trim();

        if(businessName.isEmpty()){
            ToastUtils.shortToast(context.getString(R.string.enter_businessName));
            business_name.requestFocus();
        }
        else if(businessAddress.isEmpty()){
            ToastUtils.shortToast(context.getString(R.string.enter_businessAddress));
            business_address.requestFocus();
        }
        else if(managerName.isEmpty()){
            ToastUtils.shortToast(context.getString(R.string.enter_managerName));
            manager_name.requestFocus();
        }
//        else if(phoneNumber.isEmpty()){
//            ToastUtils.shortToast(context.getString(R.string.enter_phoneNumber));
//            phone_number.requestFocus();
//        }
//        else if(phoneNumber.length() < 8 || phoneNumber.length() >15){
//            ToastUtils.shortToast(context.getString(R.string.enter_valid_phoneNumber));
//            phone_number.requestFocus();
//        }
        else if(from.equalsIgnoreCase("normal") && emailAddress.isEmpty()){
            ToastUtils.shortToast(context.getString(R.string.enter_emailAddress));
            email.requestFocus();
        }
//        else if(phoneNumberStudent.isEmpty()){
//            ToastUtils.shortToast(context.getString(R.string.enter_phoneNumber_student));
//            phone_number_student.requestFocus();
//        }
        else if(from.equalsIgnoreCase("normal") && emailStudent.isEmpty()){
            ToastUtils.shortToast(context.getString(R.string.enter_email_student));
            email_student.requestFocus();
        }
        else if(from.equalsIgnoreCase("normal") && txt_password.isEmpty()){
            ToastUtils.shortToast(context.getString(R.string.please_enter_password));
            password.requestFocus();
        }
        else if(from.equalsIgnoreCase("normal") && txt_password.length() < 6){
            ToastUtils.shortToast(context.getString(R.string.password_length));
            password.requestFocus();
        }
        else if(from.equalsIgnoreCase("normal") && confirmPassword.isEmpty()){
            ToastUtils.shortToast(context.getString(R.string.enter_confirm_password));
            confirm_password.requestFocus();
        }
        else if(from.equalsIgnoreCase("normal") && !(txt_password.equalsIgnoreCase(confirmPassword))){
            ToastUtils.shortToast(context.getString(R.string.password_mismatch));
            confirm_password.requestFocus();
        }
        else{
            signupView.onValidationSuccess();
        }
    }

    @Override
    public void businessSignup(String business_name, String business_address, String manager_name, String phone_number, String email, String phone_number_student, String email_student, String password, JSONArray nearbyColleges, String device_type, String device_token) {
        interactor.businessSignup(business_name,business_address,manager_name,phone_number,email,phone_number_student,email_student,password,nearbyColleges,device_type,device_token,this);
    }

    @Override
    public void onSuccess(BusinessSignup response) {
        signupView.onSuccess(response);
    }

    @Override
    public void onFailure(Throwable throwable) {
        signupView.onFailure(throwable.getMessage());
    }
}
