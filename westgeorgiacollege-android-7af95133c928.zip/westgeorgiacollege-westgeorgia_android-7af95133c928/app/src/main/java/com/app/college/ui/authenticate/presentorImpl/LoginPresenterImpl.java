package com.app.college.ui.authenticate.presentorImpl;

import android.content.Context;
import android.widget.EditText;

import com.app.college.R;
import com.app.college.data.login.LoginBean;
import com.app.college.ui.authenticate.interactor.LoginInteractor;
import com.app.college.ui.authenticate.intractorImpl.LoginInteractorImpl;
import com.app.college.ui.authenticate.presenter.LoginPresenter;
import com.app.college.ui.authenticate.view.LoginView;
import com.app.college.utils.ToastUtils;

/**
 * Created by ubuntu on 19/7/18.
 */

public class LoginPresenterImpl implements LoginPresenter, LoginInteractor.OnCompleteListener {


    LoginView loginView;
    Context context;
    LoginInteractor interactor;

    public LoginPresenterImpl(LoginView loginView, Context context) {
        this.loginView = loginView;
        this.context = context;
        interactor = new LoginInteractorImpl();
    }

    @Override
    public void validateCredentials(EditText email, EditText password) {
        String txtEmail = email.getText().toString().trim();
        String txtPassword = password.getText().toString().trim();

        if(txtEmail.isEmpty()){
            ToastUtils.shortToast(context.getString(R.string.please_enter_email));
            email.requestFocus();
        }
        else if(txtPassword.isEmpty()){
            ToastUtils.shortToast(context.getString(R.string.please_enter_password));
            password.requestFocus();
        }
        else{
            loginView.onValidationSuccess();
        }

    }

    @Override
    public void login(String email, String password, String deviceType, String deviceToken) {
        interactor.login(email,password,deviceType,deviceToken,this);
    }

    @Override
    public void onSuccess(LoginBean response) {
        loginView.onSuccess(response);
    }

    @Override
    public void onFailure(Throwable throwable) {
        loginView.onFailure(throwable.getMessage());
    }
}
