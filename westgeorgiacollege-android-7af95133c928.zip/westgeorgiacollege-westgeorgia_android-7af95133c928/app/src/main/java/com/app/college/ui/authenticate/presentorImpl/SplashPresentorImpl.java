package com.app.college.ui.authenticate.presentorImpl;

import com.app.college.ui.authenticate.contract.SplashContract;
import com.app.college.ui.authenticate.intractorImpl.SplashIntractorImpl;

/**
 * Created by 123 on 04-Jan-18.
 */

public class SplashPresentorImpl implements SplashContract.Presentor, SplashContract.OnCompleteListener {

    private SplashContract.Intractor intractor;
    private SplashContract.View view;

    public SplashPresentorImpl(SplashContract.View view) {
        this.view = view;
        intractor = new SplashIntractorImpl();
    }

    @Override
    public void attachView(SplashContract.View view) {

    }

    @Override
    public void dropView() {

    }

    @Override
    public void callNext() {
        intractor.waitForNext(this);
    }

    @Override
    public void onSuccess() {
        view.next();
    }
}
