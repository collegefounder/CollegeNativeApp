package com.app.college.ui.authenticate.presentorImpl;

import android.content.Context;
import android.widget.EditText;

import com.app.college.R;
import com.app.college.data.studentSignUp.StudentSignup;
import com.app.college.ui.authenticate.interactor.StudentSignupInteractor;
import com.app.college.ui.authenticate.intractorImpl.StudentSignUpInteractorImpl;
import com.app.college.ui.authenticate.presenter.StudentSignUpPresenter;
import com.app.college.ui.authenticate.view.StudentSignUpView;
import com.app.college.utils.ToastUtils;

/**
 * Created by ubuntu on 19/7/18.
 */

public class StudentSignUpPresenterImpl implements StudentSignUpPresenter, StudentSignupInteractor.OnCompleteListener {


    StudentSignUpView signupView;
    Context context;
    StudentSignupInteractor interactor;

    public StudentSignUpPresenterImpl(StudentSignUpView signupView, Context context) {
        this.signupView = signupView;
        this.context = context;
        interactor = new StudentSignUpInteractorImpl();
    }

    @Override
    public void validateCredentials(EditText firstName, EditText lastName, EditText address, EditText email, EditText phoneNumber, EditText password, EditText confirmPassword, String from) {
        String first_name=firstName.getText().toString().trim();
        String last_name=lastName.getText().toString().trim();
        String txtAddress = address.getText().toString().trim();
        String txtEmail = email.getText().toString().trim();
        String txtNumber = phoneNumber.getText().toString().trim();
        String txtPassword = password.getText().toString().trim();
        String confirm = confirmPassword.getText().toString().trim();

        if(first_name.isEmpty()){
            ToastUtils.shortToast(context.getString(R.string.enter_firstname));
            firstName.requestFocus();
        }
        else if(last_name.isEmpty()){
            ToastUtils.shortToast(context.getString(R.string.enter_lastname));
            lastName.requestFocus();
        }
        else if(from.equalsIgnoreCase("normal") && txtEmail.isEmpty()){
            ToastUtils.shortToast(context.getString(R.string.please_enter_email));
            email.requestFocus();
        }
//        else if(txtNumber.isEmpty()){
//            ToastUtils.shortToast(context.getString(R.string.please_enter_number));
//            phoneNumber.requestFocus();
//        }
//        else if(txtNumber.length() < 8 || txtNumber.length() >15){
//            ToastUtils.shortToast(context.getString(R.string.please_enter_valid_number));
//            phoneNumber.requestFocus();
//        }
        else if(from.equalsIgnoreCase("normal") &&  txtAddress.isEmpty()){
            ToastUtils.shortToast(context.getString(R.string.please_enter_address));
            address.requestFocus();
        }
        else if(from.equalsIgnoreCase("normal") && txtPassword.isEmpty()){
            ToastUtils.shortToast(context.getString(R.string.please_enter_password));
            password.requestFocus();
        }
        else if(from.equalsIgnoreCase("normal") && txtPassword.length() < 6){
            ToastUtils.shortToast(context.getString(R.string.password_length));
            password.requestFocus();
        }
        else if(from.equalsIgnoreCase("normal") && confirm.isEmpty()){
            ToastUtils.shortToast(context.getString(R.string.enter_confirm_password));
            confirmPassword.requestFocus();
        }
        else if(from.equalsIgnoreCase("normal") && !(txtPassword.equalsIgnoreCase(confirm))){
            ToastUtils.shortToast(context.getString(R.string.password_mismatch));
            confirmPassword.requestFocus();
        }
        else{
            signupView.onValidationSuccess();
        }

    }

    @Override
    public void studentSignup(String firstName, String lastName, String address, String email, String phoneNumber, String password, String deviceType, String deviceToken) {
        interactor.studentSignup(firstName,lastName,address,email,phoneNumber,password,deviceType,deviceToken,this);
    }

    @Override
    public void onSuccess(StudentSignup response) {
        signupView.onSuccess(response);
    }

    @Override
    public void onFailure(Throwable throwable) {
        signupView.onFailure(throwable.getMessage());
    }
}
