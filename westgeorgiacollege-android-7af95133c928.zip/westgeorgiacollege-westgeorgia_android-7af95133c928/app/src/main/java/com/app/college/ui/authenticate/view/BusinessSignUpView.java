package com.app.college.ui.authenticate.view;

import com.app.college.data.businessSignup.BusinessSignup;
import com.app.college.data.studentSignUp.StudentSignup;

/**
 * Created by ubuntu on 19/7/18.
 */

public interface BusinessSignUpView {

    void onSuccess(BusinessSignup response);
    void onFailure(String throwable);
    void onValidationSuccess();

}
