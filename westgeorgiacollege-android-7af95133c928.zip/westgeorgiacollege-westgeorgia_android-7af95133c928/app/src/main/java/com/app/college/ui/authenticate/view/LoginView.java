package com.app.college.ui.authenticate.view;

import com.app.college.data.login.LoginBean;

/**
 * Created by ubuntu on 19/7/18.
 */

public interface LoginView {

    void onSuccess(LoginBean response);
    void onFailure(String throwable);
    void onValidationSuccess();

}
