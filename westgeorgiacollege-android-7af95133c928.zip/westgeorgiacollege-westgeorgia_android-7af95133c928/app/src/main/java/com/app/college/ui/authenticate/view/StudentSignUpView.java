package com.app.college.ui.authenticate.view;

import com.app.college.data.studentSignUp.StudentSignup;

/**
 * Created by ubuntu on 19/7/18.
 */

public interface StudentSignUpView {

    void onSuccess(StudentSignup response);
    void onFailure(String throwable);
    void onValidationSuccess();

}
