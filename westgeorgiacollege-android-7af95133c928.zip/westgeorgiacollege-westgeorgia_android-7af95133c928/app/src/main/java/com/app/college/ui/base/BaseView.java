package com.app.college.ui.base;

/**
 * Created by 123 on 04-Jan-18.
 */

public interface BaseView<T> {

}
