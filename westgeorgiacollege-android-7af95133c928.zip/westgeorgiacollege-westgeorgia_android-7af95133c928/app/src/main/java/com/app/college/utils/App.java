package com.app.college.utils;

import android.app.Application;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Handler;
import android.view.View;
import android.view.Window;
import android.widget.LinearLayout;

import com.app.college.R;
import com.app.college.UserInterface.authenticate.login.LoginActivity;
import com.app.college.utils.helpers.SharedPreferenceHelper;

/**
 * Created by 123 on 04-Jan-18.
 */

public class App extends Application {

    private static App instance;
    private static Handler handler;

    public static App getInstance() {
        return instance;
    }

    public static boolean hasNetwork() {
        return instance.checkIfHasNetwork();
    }

    @Override
    public void onCreate() {
        super.onCreate();

        instance = this;
        handler = new Handler();
        iniSharedHelper();
    }

    private void iniSharedHelper() {
        SharedPreferenceHelper.init(this);
    }

    public boolean checkIfHasNetwork() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        return networkInfo != null && networkInfo.isConnected();
    }

    public static void tokenDialog(Context context){

        final Dialog dialog = new Dialog(context,R.style.DialogTheme);
        dialog.setCancelable(false);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.layout_token_logout);
        LinearLayout llOk = (LinearLayout) dialog.findViewById(R.id.ll_ok);
        llOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                logout();
            }
        });
        dialog.show();
    }

    public static void startLoginActivity(final Context context, final int resposeCode) {
        handler.post(new Runnable() {
            @Override
            public void run() {
                if (resposeCode == 401) {
                    tokenDialog(context);
                }
            }
        });

    }

    public static void logout(){
        new SharedPreferenceHelper(getInstance()).savePref(Constants.LOGED_IN, false);
        Intent settings = new Intent(getInstance(), LoginActivity.class);
        settings.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_NEW_TASK);
        getInstance().startActivity(settings);
    }

}
