package com.app.college.utils;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.TextView;

import com.app.college.R;


public class CommonMethods {

    static ProgressDialog mProgress;

    public static void yesNoDialog(final String type, String title, String subtitle, final YesNoDialogListener yesNoDialogListener, Context context) {
        final Dialog mDialog = new Dialog(context, R.style.MyDialog);
        mDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        Window window = mDialog.getWindow();
        window.setGravity(Gravity.CENTER);
        window.setGravity(Gravity.CENTER_VERTICAL);
        window.setBackgroundDrawable(new ColorDrawable(context.getResources().getColor(R.color.transparent_image)));
        mDialog.setCancelable(false);

        mDialog.setContentView(R.layout.dialog_layout);

        TextView tvTitle = (TextView) mDialog.findViewById(R.id.tv_title);
        TextView tvSubTitle = (TextView) mDialog.findViewById(R.id.tv_sub_title);
        TextView tvYes = (TextView) mDialog.findViewById(R.id.tv_yes);
        TextView tvNo = (TextView) mDialog.findViewById(R.id.tv_no);


        tvTitle.setText(title);
        tvSubTitle.setText(subtitle);


        tvYes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mDialog.dismiss();
                yesNoDialogListener.yesClicked(type);
            }
        });

        tvNo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mDialog.dismiss();
                yesNoDialogListener.noClicked(type);
            }
        });
        mDialog.show();
    }

    public static void showProgress(Context mContext) {
        try {
            if (mProgress == null) {
                mProgress = new ProgressDialog(mContext);
                mProgress.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            }
            mProgress.show();
            mProgress.setContentView(R.layout.dialog_progress);
            mProgress.setCancelable(false);
        } catch (Exception e) {
            e.printStackTrace();
            mProgress = null;
        }
    }


//    public static void hideKeyboard(Context context, EditText editText){
//        InputMethodManager inputMethodManager = (InputMethodManager) context.getSystemService(INPUT_METHOD_SERVICE);
//        inputMethodManager.hideSoftInputFromWindow(editText.getWindowToken(), 0);
//    }


    public static void hideProgress() {
        try {
            if (mProgress != null) {
                mProgress.hide();
                mProgress.dismiss();
                mProgress = null;
            }
        } catch (Exception e) {
            e.printStackTrace();
            mProgress = null;
        }
    }

}
