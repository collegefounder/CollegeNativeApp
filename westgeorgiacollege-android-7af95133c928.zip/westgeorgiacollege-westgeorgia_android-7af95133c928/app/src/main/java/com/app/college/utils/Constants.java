package com.app.college.utils;

/**
 * Created by 123 on 04-Jan-18.
 */

public class Constants {

    public final static String MONTSERRAT_REGULAR = "Montserrat_regular.otf";
    public final static String MONTSERRAT_SEMI_BOLD = "Montserrat_SemiBold.otf";
    public final static String MONTSERRAT_LIGHT = "Montserrat_Light.otf";
    public final static String MONTSERRAT_MEDIUM = "Montserrat_Medium.otf";
    public static final String FORGOT_PASSWORD = "Forgot_Password";
    public static final String LOGOUT = "Logout";
    public static final String FB_ACCESS_TOKEN = "fb_access_token";
    public static final String FB_USER_ID = "fb_id";
    public static final String LOGED_IN = "loged_in";
    public static final String AUTH_TOKEN = "auth_token";
    public static final String EMAIL ="email" ;
    public static int SPLASH_TIME = 3000;
    public static String CLICKED_INST="clicked_ins";
    public static final String NO_INTERNET_CONNECTION = "No Internet Connection";

    public static String LOGED_STUDENT="logged_student";
}
