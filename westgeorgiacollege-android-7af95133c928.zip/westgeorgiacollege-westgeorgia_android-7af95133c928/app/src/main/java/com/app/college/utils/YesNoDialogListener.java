package com.app.college.utils;

/**
 * Created by 123 on 30-Jan-18.
 */

public interface YesNoDialogListener {

    public void yesClicked(String type);

    public void noClicked(String type);
}
