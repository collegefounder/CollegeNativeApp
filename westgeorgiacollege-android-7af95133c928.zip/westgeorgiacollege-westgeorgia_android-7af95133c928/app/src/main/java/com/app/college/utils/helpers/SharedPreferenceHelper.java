package com.app.college.utils.helpers;

import android.content.Context;
import android.content.SharedPreferences;

import com.app.college.utils.ErrorUtils;

/**
 * Created by 123 on 04-Jan-18.
 */

public class SharedPreferenceHelper {

    public static final String TAG = SharedPreferenceHelper.class.getSimpleName();
    public static final String NAME = "encrypt";
    public static final String IS_LOGIN = "isLogin";
    public static final String ACCESS_TOKEN = "access_token";
    public static final String GOOGLE_PROFILE_PIC = "google_profile_pic";

    private static SharedPreferenceHelper instance;
    protected final SharedPreferences sharedPreferences;
    protected final SharedPreferences.Editor sharedPreferencesEditor;

    public static void init(Context context) {
        if (instance == null) {
            instance = new SharedPreferenceHelper(context);
        }
    }

    public SharedPreferenceHelper(Context context) {
        sharedPreferences = context.getSharedPreferences(NAME, Context.MODE_PRIVATE);
        sharedPreferencesEditor = sharedPreferences.edit();
    }

    public static SharedPreferenceHelper getInstance() {
        if (instance == null) {
            ErrorUtils.logError(TAG, "SharedPreferenceHelper was not initialized!");
        }
        return instance;
    }

    private void delete(String key) {
        if (sharedPreferences.contains(key)) {
            sharedPreferencesEditor.remove(key).commit();
        }
    }

    public void savePref(String key, Object value) {
        delete(key);

        if (value instanceof Boolean) {
            sharedPreferencesEditor.putBoolean(key, (Boolean) value);
        } else if (value instanceof Integer) {
            sharedPreferencesEditor.putInt(key, (Integer) value);
        } else if (value instanceof Float) {
            sharedPreferencesEditor.putFloat(key, (Float) value);
        } else if (value instanceof Long) {
            sharedPreferencesEditor.putLong(key, (Long) value);
        } else if (value instanceof String) {
            sharedPreferencesEditor.putString(key, (String) value);
        } else if (value instanceof Enum) {
            sharedPreferencesEditor.putString(key, value.toString());
        } else if (value != null) {
            ErrorUtils.logError(TAG, "Attempting to save non-primitive preference");
        }
        sharedPreferencesEditor.commit();
    }

    public <T> T getPref(String key) {
        return (T) sharedPreferences.getAll().get(key);
    }

    public <T> T getPref(String key, T defValue) {
        T returnValue = (T) sharedPreferences.getAll().get(key);
        return returnValue == null ? defValue : returnValue;
    }

    public void clearAll() {
        sharedPreferencesEditor.clear();
        sharedPreferencesEditor.commit();
    }

    public void saveIsLogin(boolean isLogin) {
        savePref(IS_LOGIN, isLogin);
    }

    public boolean getIsLogin() {
        return getPref(IS_LOGIN, false);
    }

    public void saveAccessToken(String access_token) {
        savePref(ACCESS_TOKEN, access_token);
    }

    public String getAccessToken() {
        return getPref(ACCESS_TOKEN, "");
    }


    public void saveGoogleProfilePic(String profilePic) {
        savePref(GOOGLE_PROFILE_PIC, profilePic);
    }

    public String getGoogleProfilePic() {
        return getPref(GOOGLE_PROFILE_PIC, "");
    }
}
