package com.app.college.utils.listener;

import android.view.View;

/**
 * Created by ubuntu on 20/7/18.
 */

public interface AddListener {

    void onClick(View view, int position);

}
