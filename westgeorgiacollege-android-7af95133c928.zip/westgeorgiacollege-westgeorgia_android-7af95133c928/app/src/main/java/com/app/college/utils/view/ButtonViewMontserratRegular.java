package com.app.college.utils.view;

import android.content.Context;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.widget.Button;

import com.app.college.utils.Constants;

public class ButtonViewMontserratRegular extends Button {

    private Context context;

    public ButtonViewMontserratRegular(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.context = context;
        init();
    }

    private void init() {
        Typeface typeface = Typeface.createFromAsset(context.getAssets(), Constants.MONTSERRAT_REGULAR);
        setTypeface(typeface);
    }
}
