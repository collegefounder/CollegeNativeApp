package com.app.college.utils.view;

import android.content.Context;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.widget.EditText;

import com.app.college.utils.Constants;

/**
 * Created by 123 on 04-Jan-18.
 */

public class EditTextMontserratSemiBold extends EditText{

    private Context context;

    public EditTextMontserratSemiBold(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.context = context;
        init();
    }

    private void init() {
        Typeface typeface = Typeface.createFromAsset(context.getAssets(), Constants.MONTSERRAT_SEMI_BOLD);
        setTypeface(typeface);
    }
}
